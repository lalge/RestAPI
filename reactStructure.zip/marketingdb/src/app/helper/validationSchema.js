// import * as Yup from 'yup';
export const personInfoSchema = {
    // firstName: Yup.string()
    //     .max(25, 'First Name must be 25 characters or less')
    //     .required('Please enter First Name')
    //     .matches(/^[a-zA-Z]*$/,'Please enter valid First Name'),
    // lastName: Yup.string()
    // .max(25, 'Last Name must be 25 characters or less')
    // .required('Please enter Last Name')
    // .matches(/^[a-zA-Z]*$/,'Please enter valid Last Name'),
    // email: Yup.string()
    //     .email('Please enter valid buisness email')
    //     .required('Please enter buisness email'),
};
export const corporateInfoSchema = {
    // designation: Yup.string().required("Please enter Designation")
}