import asyncComponent from '../hoc/asyncComponent';

const ClientUsersListing = asyncComponent(() => import('../views/ClientUsers/Listing'));
const SubscriptionHistoryListing = asyncComponent(() => import('../views/SubscriptionHistory/Listing'));
const CustomerProfile = asyncComponent(() => import('../views/ClientUsers/Profile'));
const NotFound = asyncComponent(() => import('../components/Error404/index'));
const allRoute = [
  // { path: '/', exact: true, name: 'Route' },
  { path: '/app/client-users', name: 'Client Users', component: ClientUsersListing },
  { path: '/app/subscription-history', name: 'Subscription History', component: SubscriptionHistoryListing },
  { path: '/app/customer/:customerId', exact: true, name: 'Customer Profile', component: CustomerProfile },
  { path: '', exact: true, name: 'Error 404', component: NotFound },
];

const routeNavigation = [
  {
    parent: 'Users Management',
    parentIcon: 'zmdi zmdi-accounts-list-alt zmdi-hc-fw',
    childNav: [
      {
        child: "Client Users",
        path: "/app/client-users"
      }
    ]
  },
  {
    parent: 'Subscription',
    parentIcon: 'zmdi zmdi-accounts-list-alt zmdi-hc-fw',
    childNav: [
      {
        child: "Subscription History",
        path: "/app/subscription-history"
      }
    ]

  }
]

export { allRoute,routeNavigation };
