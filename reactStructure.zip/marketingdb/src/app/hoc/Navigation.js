import React from "react";
import { NavLink } from "react-router-dom";
import Button from '@material-ui/core/Button';
const Navigation = (props) => {
    const {routeNav } = props;
    if (routeNav.childNav.length !== 0) {
      return (
        <li className="menu collapse-box">
          <Button>
            <i className={routeNav.parentIcon} />
            <span className="nav-text">
              {routeNav.parent}
            </span>
          </Button>
          <ul className="sub-menu">
            {routeNav.childNav.map((childNav,index)=>(
              <li key={index}>
              <NavLink className="prepend-icon" to={childNav.path}>
                <span className="nav-text">{childNav.child} </span>
              </NavLink>
            </li>
            ))}

          </ul>
        </li>

      );
    } else {
      return (null);
    }
  }

  export default Navigation;