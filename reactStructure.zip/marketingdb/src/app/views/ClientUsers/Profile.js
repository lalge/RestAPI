import React, { useState, useEffect } from 'react';
import { UserApi, getClientUsers } from '../../../store/middelware/api/UsersApi';
import About from "../../components/profile/About/index";
import Subscription from "../../components/profile/Subscription/index";
import Contact from "../../components/profile/Contact/index";
import Auxiliary from "../../../utilities/Auxiliary";
import Snackbar from '@material-ui/core/Snackbar';
import CircularProgress from '../../components/CircularProgress';
import { aboutList, contactList, addressList, relationshipData } from './clientData';
import { getDateFromMongoDate } from '../../../utilities/utilities';

const Details = (props) => {
  const custId = props.match.params.customerId;
  const [loading, setLoading] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [showMessage, setShowMessage] = useState(false);
  const [allSubscription,setAllSubscription] = useState([]);
  const handleRequestClose = () => {
    setShowMessage(false);
  };

  useEffect(() => {
    setLoading(true);
    const Customer = UserApi(getClientUsers, "customerId=" + custId);
    Customer.then((response) => {

      try {
        if (response.status === 200) {
          const UserData = response.data[0] || {};
          if (Object.keys(UserData).length) {
            const userSubscription = [];
            const subscription = UserData.user_subscription || [];
            aboutList.userName.desc = [UserData.user_fname + " " + UserData.user_lname];
            aboutList.workAt.desc = [typeof UserData.user_company[0] === 'undefined' ? '' : UserData.user_company[0].company_name];
            aboutList.activeSince.desc = [getDateFromMongoDate(UserData.user_created_date)];
            aboutList.designation.desc = [UserData.user_designation];
            aboutList.status.desc = [UserData.user_active === 1 ? "Active" : "In-active"];
            let userAddress = [];
            userAddress.push(typeof UserData.user_address_office ==='undefined'?'':UserData.user_address_office[0].office_address1 || "");
            userAddress.push(typeof UserData.user_address_office ==='undefined'?'':UserData.user_address_office[0].office_address2 || "");
            userAddress.push(typeof UserData.user_address_office ==='undefined'?'':UserData.user_address_office[0].office_state || "");
            userAddress.push(typeof UserData.user_address_office ==='undefined'?'':UserData.user_address_office[0].office_city || "");
            userAddress.push(typeof UserData.user_address_office ==='undefined'?'':UserData.user_address_office[0].office_zip_code || "");
            userAddress = userAddress.filter((address) => address !== '');
            addressList.user_address_office.desc = [userAddress.join(", ")];
            userAddress = [];
            userAddress.push(typeof UserData.user_address_billing ==='undefined'? '' : UserData.user_address_billing[0].billing_address1 || "");
            userAddress.push(typeof UserData.user_address_billing ==='undefined'? '' : UserData.user_address_billing[0].billing_address2 || "");
            userAddress.push(typeof UserData.user_address_billing ==='undefined'? '' : UserData.user_address_billing[0].billing_state || "");
            userAddress.push(typeof UserData.user_address_billing ==='undefined'? '' : UserData.user_address_billing[0].billing_city || "");
            userAddress.push(typeof UserData.user_address_billing ==='undefined'? '' : UserData.user_address_billing[0].billing_zip_code || "");
            userAddress = userAddress.filter((address) => address !== '');
            addressList.user_address_billing.desc = [userAddress.join(", ")];
            userAddress = [];
            userAddress.push(typeof UserData.user_address_service_use === 'undefined' ? '' : UserData.user_address_service_use[0].platform_address1 || "");
            userAddress.push(typeof UserData.user_address_service_use === 'undefined' ? '' : UserData.user_address_service_use[0].platform_address2 || "");
            userAddress.push(typeof UserData.user_address_service_use === 'undefined' ? '' : UserData.user_address_service_use[0].platform_state || "");
            userAddress.push(typeof UserData.user_address_service_use === 'undefined' ? '' : UserData.user_address_service_use[0].platform_city || "");
            userAddress.push(typeof UserData.user_address_service_use === 'undefined' ? '' : UserData.user_address_service_use[0].platform_zip_code || "");
            userAddress = userAddress.filter((address) => address !== '');
            addressList.user_address_service_use.desc = [userAddress.join(", ")];
            contactList.email.desc = [UserData.user_email];
            contactList.phone.desc = [UserData.user_mobile];

            relationshipData.btb_id.desc = [UserData.btb_id];
            relationshipData.user_relationship_manager_email.desc = [UserData.user_relationship_manager_email];
            relationshipData.user_relationship_manager_name.desc = [UserData.user_relationship_manager_name];
            subscription.forEach(subscriptionElement => {
              userSubscription.push({
                title: subscriptionElement.subscription_product_services.product_name || '',
                dtName: subscriptionElement.dt_name || '',
                industryName:subscriptionElement.industry_name ||'',
                subscriptionProductType: subscriptionElement.subscription_product_type || '',
                subscriptionType: subscriptionElement.subscription_type || '',
                userPackageDays: typeof subscriptionElement.user_package === 'undefined' ? '' : subscriptionElement.user_package.package_days || '',
                maxPatentPerListingRegister: typeof subscriptionElement.user_package === 'undefined' ? '' : subscriptionElement.user_package.max_patent_per_listing_register || '',
                maxCompaniesPerListingRegister: typeof subscriptionElement.user_package === 'undefined' ? '' : subscriptionElement.user_package.max_companies_per_listing_register || '',
                maxProductsPerListingRegister: typeof subscriptionElement.user_package === 'undefined' ? '' : subscriptionElement.user_package.max_products_per_listing_register || '',
                showListingTotalCount: typeof subscriptionElement.user_package === 'undefined' ? '' : subscriptionElement.user_package.show_listing_total_count || '',
                startDate: typeof subscriptionElement.user_package === 'undefined' ? '' : getDateFromMongoDate(subscriptionElement.user_package.start_date),
                endDate: typeof subscriptionElement.user_package === 'undefined' ? '' : getDateFromMongoDate(subscriptionElement.user_package.end_date),
                analystHours: subscriptionElement.analyst_hours || '',
                analystHoursUsed: subscriptionElement.analyst_hours_used || '',
              })
            });
            setAllSubscription(userSubscription);
          } else {
            throw Object.assign(
              new Error("SOMETHING WENT WRONG"),
              { code: 500 }
            );
          }
          setLoading(false);
        } else {
          throw Object.assign(
            new Error("SOMETHING WENT WRONG"),
            { code: 500 }
          );
        }
      }
      catch (err) {
        console.log("SOMETHING WENT WRONG WHILE PROCESSING", err);
        setShowMessage(true);
        setAlertMessage("SOMETHING WENT WRONG WHILE PROCESSING");
        setTimeout(() => {
          setLoading(false);
          props.history.goBack();
        }, 3000)

      }
    }).catch((err) => {
      setShowMessage(true);
      setAlertMessage("ERROR WHILE FETCHING SUBSCRIPTION");
      console.log("ERROR WHILE FETCHING SUBSCRIPTION", err);
      setTimeout(() => {
        setLoading(false);
        props.history.goBack();
      }, 3000)
    })
    // props.history.goBack();
  }, [custId,props.history])

  return (
    <div className="app-wrapper">
      <Auxiliary>
        <div className="jr-profile-content">
          {
            loading ? <div className="loader-view-block h-100">
              <div className="loader-view">
                <CircularProgress />
              </div>
            </div> :
              <div className="row">
                <div className="col-xl-8 col-lg-8 col-md-7 col-12">
                  <About
                    aboutList={aboutList}
                    addressList={addressList}
                  />
                  {allSubscription.length === 0 ? null :
                  <Subscription
                    subscriptionList={allSubscription}
                  />}
                </div>
                <div className="col-xl-4 col-lg-4 col-md-5 col-12">
                  <Contact
                    contactList={contactList}
                    title={"Contact"}
                  />
                  <div className="row">
                    <div className="col-12">
                      <Contact
                        contactList={relationshipData}
                        title="Futurebridge-Link"
                      />
                    </div>
                  </div>
                </div>
              </div>
          }

        </div>
        <Snackbar
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
          open={showMessage}
          autoHideDuration={5000}
          onClose={handleRequestClose}
          ContentProps={{
            'aria-describedby': 'message-id',
          }}
          message={<span id="message-id">{alertMessage}</span>}
        />
      </Auxiliary>
    </div>
  );
};
export default Details;