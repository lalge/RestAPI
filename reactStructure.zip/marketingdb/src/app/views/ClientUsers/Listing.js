import React, { Component } from 'react';
import Drawer from '@material-ui/core/Drawer';
import IconButton from '@material-ui/core/IconButton';
import Container from '@material-ui/core/Container';
import Checkbox from '@material-ui/core/Checkbox';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import ContactList from '../../components/contact/ContactList'
import AppModuleHeader from '../../components/AppModuleHeader/index';
import CustomScrollbars from '../../../utilities/CustomScrollbars';
import { UserApi, getAllClientUsers, createClientUser, getClientUsers } from '../../../store/middelware/api/UsersApi';
import UserForm from "./UserForm";
import InfoView from '../../components/InfoView/Infoview';
const filterOptions = [
  {
    id: 1,
    name: 'All Client',
    icon: 'zmdi-menu'
  }, {
    id: 2,
    name: 'Active Client',
    icon: 'zmdi-star'

  }, {

    id: 3,
    name: 'In-active Client',
    icon: 'zmdi-time-restore'
  }
];

class ClientUser extends Component {

  ContactSideBar = () => {
    return <div className="module-side">
      <div className="module-side-header">
        <div className="module-logo">
          <i className="zmdi zmdi-account-box mr-4" />
          <span>Client Users</span>
        </div>
      </div>

      <div className="module-side-content">
        <CustomScrollbars className="module-side-scroll scrollbar"
          style={{ height: this.props.width >= 1200 ? 'calc(100vh - 200px)' : 'calc(100vh - 80px)' }}>
          <div className="module-add-task">
            <Button className="jr-btn btn-block" variant="contained" color="primary" aria-label="add"
              onClick={this.onAddContact}>
              <i className="zmdi zmdi-account-add zmdi-hc-fw" />
              <span>Add New Client</span>
            </Button>
          </div>
          <div className="module-side-nav">
            <ul className="module-nav">
              {filterOptions.map(option => <li key={option.id} className="nav-item">
                <span
                  className={`jr-link ${option.id === this.state.selectedSectionId ? 'active' : ''}`} onClick={
                    this.onFilterOptionSelect.bind(this, option)
                  }>
                  <i className={`zmdi ${option.icon}`} />
                  <span>{option.name}</span>
                </span>
              </li>
              )}

            </ul>
          </div>
        </CustomScrollbars>
      </div>
    </div>

  };


  onContactSelect = (data) => {
    data.selected = !data.selected;
    let selectedContacts = 0;
    const contactList = this.state.contactList.map(contact => {
      if (contact.selected) {
        selectedContacts++;
      }
      if (contact.id === data.id) {
        if (contact.selected) {
          selectedContacts++;
        }
        return data;
      } else {
        return contact;
      }
    }
    );
    this.setState({
      selectedContacts: selectedContacts,
      contactList: contactList
    });

  };


  onAddContact = () => {
    this.setState({
      addContactState: true,
      editContact: false,
      updateContact: {}
    });
  };
  onContactClose = () => {
    this.setState({ addContactState: false });
  };
  onFilterOptionSelect = (option) => {
    switch (option.name) {
      case 'All contacts': {
        this.setState({
          selectedSectionId: option.id,
          filterOption: option.name,
          contactList: this.state.allContact,
          addContactState: false
        });
        break;
      }
      case 'Active Client': {
        this.setState({
          selectedSectionId: option.id,
          filterOption: option.name,
          contactList: this.state.allContact.filter((contact) => contact.active),
          addContactState: false
        });
        break;
      }
      case 'In-active Client': {
        this.setState({
          selectedSectionId: option.id,
          filterOption: option.name,
          contactList: this.state.allContact.filter((contact) => contact.inactive),
          addContactState: false
        });
        break;
      }
      default: {
        this.setState({
          selectedSectionId: option.id,
          filterOption: option.name,
          contactList: this.state.allContact,
          addContactState: false
        });
      }
    }

  };
  onSaveContact = (data) => {
    this.setState({
      loader: true
    })
    const response = UserApi(createClientUser, data);
    return response.then((result) => {
      try {
        const responseData = result.data || {};
        if (responseData.response === "success") {
          this.setState({
            loader: false,
            alertMessage:'Client User Created Successfully'
          })
        } else {
          throw Object.assign(
            new Error("SOMETHING WENT WRONG"),
            { code: 500 }
          );
        }
      }
      catch (err) {
        this.setState({
          loader: false,
          alertMessage:'Something Went Wrong'
        })
      }
    })
    .catch((err) => {
      this.setState({
        loader: false,
        alertMessage:'Something Went Wrong'
      })
    })
    // let isNew = true;
    // const contactList = this.state.allContact.map((contact) => {
    //   if (contact.id === data.id) {
    //     isNew = false;
    //     return data
    //   } else {
    //     return contact
    //   }
    // });
    // if (isNew) {
    //   contactList.push(data);
    // }
    // this.setState({
    //   alertMessage: isNew ? 'Contact Added Successfully' : 'Contact Updated Successfully',
    //   showMessage: true,
    //   contactList: contactList,
    //   allContact: contactList
    // });
    // this.onFilterOptionSelect(this.state.filterOption);
  };
  onDeleteContact = (data) => {
    this.setState({
      alertMessage: 'Contact Deleted Successfully',
      showMessage: true,
      allContact: this.state.allContact.filter((contact) => contact.id !== data.id),
      contactList: this.state.allContact.filter((contact) => contact.id !== data.id)
    })
  };
  onDeleteSelectedContact = () => {
    const contacts = this.state.allContact.filter((contact) => !contact.selected);
    this.setState({
      alertMessage: 'Contact Deleted Successfully',
      showMessage: true,
      allContact: contacts,
      contactList: contacts,
      selectedContacts: 0
    })
  };
  filterContact = (userName) => {
    const { filterOption } = this.state;
    if (userName === '') {
      this.setState({ contactList: this.state.allContact });
    } else {
      const filterContact = this.state.allContact.filter((contact) =>
        contact.name.toLowerCase().indexOf(userName.toLowerCase()) > -1);
      if (filterOption === 'All contacts') {
        this.setState({ contactList: filterContact });
      } else if (filterOption === 'Active Client') {
        this.setState({ contactList: filterContact.filter((contact) => contact.active) });

      } else if (filterOption === 'In-active Client') {
        this.setState({ contactList: filterContact.filter((contact) => contact.inactive) });
      }
    }
  };
  handleRequestClose = () => {
    this.setState({
      showMessage: false,
    });
  };
  getAllContact = () => {
    let contactList = this.state.allContact.map((contact) => contact ? {
      ...contact,
      selected: true
    } : contact);
    this.setState({
      selectedContacts: contactList.length,
      allContact: contactList,
      contactList: contactList
    });
  };
  getUnselectedAllContact = () => {
    let contactList = this.state.allContact.map((contact) => contact ? {
      ...contact,
      selected: false
    } : contact);
    this.setState({
      selectedContacts: 0,
      allContact: contactList,
      contactList: contactList
    });
  };

  onEditContact = (contact) => {
    this.setState({
      loader: true
    })
    const Client = UserApi(getClientUsers, "customerId=" + contact.id);
    Client.then((response) => {

      if (response.status === 200) {
        this.setState({
          loader: false,
          addContactState: true,
          editContact: true,
          updateContact: response.data[0] || {}
        })
      } else {
        this.setState({
          alertMessage: 'Something went wrong',
          showMessage: true,
        })
        throw Object.assign(
          new Error("SOMETHING WENT WRONG"),
          { code: 500 }
        );
      }
    }).catch((e) => {
      this.setState({
        loader: false
      })
      console.log("ERROR WHILE FETCHING CLIENTS", e);
    })
  }

  constructor() {
    super();
    this.state = {
      noContentFoundMessage: 'No contact found in selected folder',
      alertMessage: '',
      showMessage: false,
      selectedSectionId: 1,
      drawerState: false,
      searchUser: '',
      filterOption: 'All contacts',
      allContact: [],
      contactList: [],
      updateContact: {},
      selectedContact: null,
      selectedContacts: 0,
      addContactState: false,
      loader: false,
      editContact: false
    }
  }

  onAllContactSelect() {
    const selectAll = this.state.selectedContacts < this.state.contactList.length;
    if (selectAll) {
      this.getAllContact();
    } else {
      this.getUnselectedAllContact();
    }
  }

  updateContactUser(evt) {
    this.setState({
      searchUser: evt.target.value,
    });
    this.filterContact(evt.target.value)
  }

  onToggleDrawer() {
    this.setState({
      drawerState: !this.state.drawerState
    });
  }

  componentDidMount() {
    const clientUser = [];
    this.setState({
      loader: true
    })
    const ClientData = UserApi(getAllClientUsers);
    ClientData.then((response) => {
      this.setState({
        loader: false
      })
      if (response.status === 200) {
        response.data.forEach((data) => {
          clientUser.push(
            {
              'id': data._id,
              'name': data.user_fname + " " + data.user_lname,
              'thumb': null,
              'email': data.user_email,
              'phone': "+91919188002",
              'designation': 'CEO',
              'selected': false,
              'active': data.user_active === 1,
              'inactive': data.user_active === 0,
            }
          );
        })
        this.setState({
          allContact: clientUser,
          contactList: clientUser,
          loader: false
        })
      } else {
        this.setState({
          alertMessage: 'Something went wrong',
          showMessage: true,
        })
        throw Object.assign(
          new Error("SOMETHING WENT WRONG"),
          { code: 500 }
        );
      }
    }).catch((e) => {
      this.setState({
        loader: false
      })
      console.log("ERROR WHILE FETCHING CLIENTS", e);
    })
  }

  render() {
    const { contactList, updateContact, addContactState, selectedContacts, alertMessage, showMessage, noContentFoundMessage, loader, editContact } = this.state;
    return (
      <div className="app-wrapper">
        <div className="app-module animated slideInUpTiny animation-duration-3">

          <div className="d-block d-xl-none">
            <Drawer
              open={this.state.drawerState}
              onClose={this.onToggleDrawer.bind(this)}>
              {this.ContactSideBar()}
            </Drawer>
          </div>
          <div className="app-module-sidenav d-none d-xl-flex">
            {this.ContactSideBar()}
          </div>

          <div className="module-box">
            <div className="module-box-header">
              <IconButton className="drawer-btn d-block d-xl-none" aria-label="Menu"
                onClick={this.onToggleDrawer.bind(this)}>
                <i className="zmdi zmdi-menu" />
              </IconButton>
              {addContactState ?
                Object.keys(updateContact).length === 0 ?
                  <span className="text-center"><h2>Add New Client User</h2></span>
                  : <span className="text-center"><h2>Update Client User</h2></span>
                : <AppModuleHeader placeholder="Search Client"
                  onChange={this.updateContactUser.bind(this)}
                  value={this.state.searchUser} />}
            </div>
            <div className="module-box-content">
              {addContactState ? null :
                <div className="module-box-topbar">
                  <Checkbox color="primary"
                    indeterminate={selectedContacts > 0 && selectedContacts < contactList.length}
                    checked={selectedContacts > 0}
                    onChange={this.onAllContactSelect.bind(this)}
                    value="SelectMail" />


                  {selectedContacts > 0 &&
                    <IconButton className="icon-btn"
                      onClick={this.onDeleteSelectedContact.bind(this)}>
                      <i className="zmdi zmdi-delete" />
                    </IconButton>}

                </div>
              }
              <CustomScrollbars className="module-list-scroll scrollbar app-loader-container"
                style={{ height: this.props.width >= 1200 ? addContactState ? 'calc(100vh - 200px)' : 'calc(100vh - 261px)' : addContactState ? 'calc(100vh - 180px)' : 'calc(100vh - 240px)' }}>

                {addContactState ? <Container className="h-100"><UserForm contact={updateContact} editContact={editContact} onSaveContact={this.onSaveContact.bind(this)} /> </Container> :
                  contactList.length === 0 ?
                    <div className="h-100 d-flex align-items-center justify-content-center">
                      {loader ? '' : noContentFoundMessage}
                    </div>
                    : <ContactList contactList={contactList}
                      onContactSelect={this.onContactSelect.bind(this)}
                      onDeleteContact={this.onDeleteContact.bind(this)}
                      onEditContact={this.onEditContact.bind(this)} />
                }

                <InfoView
                  message={alertMessage}
                  loading={loader}
                  alignment="bottom"
                />
              </CustomScrollbars>

            </div>
          </div>

        </div>
      </div>
    )
  }
}

const mapStateToProps = ({ settings }) => {
  const { width } = settings;
  return { width }
};
export default connect(mapStateToProps)(ClientUser);