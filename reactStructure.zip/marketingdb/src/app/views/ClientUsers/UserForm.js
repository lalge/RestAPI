import React, { useState, useEffect } from 'react';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { useFormik } from "formik";
import { personInfoSchema, corporateInfoSchema } from "../../helper/validationSchema";
import * as Yup from 'yup';
import FormikDebug from "../../helper/FormikDebug";
import PersonalInformation from "../../components/UserForm/PersonalInformation";
import CorporateInformation from "../../components/UserForm/CorporateInformation";
import StakeholdersInformation from "../../components/UserForm/StakeholdersInformation";
import AddressInformation from "../../components/UserForm/AddressInformation";

function getSteps() {
  return ['Personal Information', 'Corporate Information', 'Stakeholders Information', 'Address'];
}

function StepContent(props) {
  const { stepIndex } = props;
  switch (stepIndex) {
    case 0:
      return (<PersonalInformation
        formik={props.formik}
      />);
    case 1:
      return (<CorporateInformation
        formik={props.formik}
      />);
    case 2:
      return <StakeholdersInformation
        formik={props.formik}
      />;
    case 3:
      return <AddressInformation
        formik={props.formik}
      />;
    default:
      return 'Uknown stepIndex';
  }
}




const UserForm = (props) => {
  const [activeStep, setActiveStep] = useState(0);
  const {onSaveContact} = props;
  
  const personalInfo = {
    firstName: 'testData',
    lastName: 'testData',
    email: 'testData@data.com',
    phone: 'testData',
    password: 'testData',
    confirmPassword: 'testData'
  };
  const corporateInfo = {
    designation: 'testData',
    company: 'testData',
    officeAddress: {
      address1: 'testData',
      address2: 'testData',
      area: 'testData',
      city_name: 'testData',
      state_name: 'testData',
      pincode: 'testData',
      zip: 'testData',
      country_name: 123123123,
      region_name: 'testData',
      telphone: 'testData'
    }
  };
  const stakeholdersInfo = {
    btbId: 'testData',
    relationshipManagerName: 'testData',
    relationshipManagerEmail: 'testData@asd.com',
    userStatus: 1
  };

  const billingAddress = {
    billingAddress: {
      address1: 'testData',
      address2: 'testData',
      area: 'testData',
      city_name: 'testData',
      state_name: 'testData',
      pincode: 'testData',
      zip: 'testData',
      country_name: 123123,
      region_name: 'testData',
      telphone: 'testData'
    }
  };

  const serviceAddress = {
    serviceAddress: {
      address1: 'testData',
      address2: 'testData',
      area: 'testData',
      city_name: 'testData',
      state_name: 'testData',
      pincode: 'testData',
      zip: 'testData',
      country_name: 123123,
      region_name: 'testData',
      telphone: 'testData'
    }
  }

  // const personalInfo = {
  //   firstName: '',
  //   lastName: '',
  //   email: '',
  //   phone: '',
  //   password: '',
  //   confirmPassword: ''
  // };
  // const corporateInfo = {
  //   designation: '',
  //   company: '',
  //   officeAddress: {
  //     address1: '',
  //     address2: '',
  //     area: "",
  //     city_name: "",
  //     state_name: "",
  //     pincode: "",
  //     zip: "",
  //     country_name: "",
  //     region_name: "",
  //     telphone: ""
  //   }
  // };
  // const stakeholdersInfo = {
  //   btbId: '',
  //   relationshipManagerName: '',
  //   relationshipManagerEmail: '',
  //   userStatus: 1
  // };

  // const billingAddress = {
  //   billingAddress: {
  //     address1: '',
  //     address2: '',
  //     area: "",
  //     city_name: "",
  //     state_name: "",
  //     pincode: "",
  //     zip: "",
  //     country_name: "",
  //     region_name: ""
  //   }
  // };

  // const serviceAddress = {
  //   serviceAddress: {
  //     address1: '',
  //     address2: '',
  //     area: "",
  //     city_name: "",
  //     state_name: "",
  //     pincode: "",
  //     zip: "",
  //     country_name: "",
  //     region_name: ""
  //   }
  // }


  const schemaArray = [
    Yup.object().shape({ ...personInfoSchema }),
    Yup.object().shape({ ...corporateInfoSchema })
  ];

  const formik = useFormik({
    initialValues: {
      ...personalInfo,
      ...corporateInfo,
      ...stakeholdersInfo,
      ...billingAddress,
      ...serviceAddress
    },
    validationSchema: schemaArray[activeStep]
  })


  useEffect(() => {
    if (props.editContact) {
      setActiveStep(0);
      formik.setValues(
        {
          firstName: props.contact.user_fname || '',
          lastName: props.contact.user_lname || '',
          email: props.contact.user_email || '',
          phone: '',
          password: '',
          confirmPassword: '',
          ...corporateInfo,
          ...stakeholdersInfo,
        }
      );
    } else {
      setActiveStep(3);
      formik.resetForm();
    }
  }, [props.editContact])

  const handleNext = () => {
    formik.validateForm().then((res) => {
      if (!Object.keys(res).length) {
        setActiveStep(activeStep + 1);
      } else {
        const touched = {};
        Object.keys(res).map((field) => {
          touched[field] = true;
        });
        formik.setFormikState({ ...formik, touched: touched, errors: res });
      }
    })

  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const handleReset = () => {
    formik.resetForm();
    setActiveStep(0);
  };

  const handleSubmit = () => {
    const { values } = formik;
    const userData = {
      "user_fname": values.firstName,
      "user_lname": values.lastName,
      "user_email": values.email,
      "user_password": values.password,
      "user_relationship_manager_name": values.relationshipManagerName,
      "user_relationship_manager_email": values.relationshipManagerEmail,
      "btb_id": values.btbId,
      "user_designation": values.designation,
      "user_company": [
        {
          "company_name": values.company_name
        }
      ],
      "user_address_office": [
        {
          "address_line1": values.officeAddress.address1,
          "address_line2": values.officeAddress.address2,
          "area": values.officeAddress.area,
          "city_name": values.officeAddress.city_name,
          "state_name": values.officeAddress.state_name,
          "country_name": values.officeAddress.country_name,
          "region_name": values.officeAddress.region_name,
          "pincode": values.officeAddress.pincode,
          "zip": values.officeAddress.zip,
          "telphone": values.officeAddress.telphone
        }
      ],
      "user_address_billing": [
        {
          "address_line1": values.billingAddress.address1,
          "address_line2": values.billingAddress.address2,
          "area": values.billingAddress.area,
          "city_name": values.billingAddress.city_name,
          "state_name": values.billingAddress.state_name,
          "country_name": values.billingAddress.country_name,
          "region_name": values.billingAddress.region_name,
          "pincode": values.billingAddress.pincode,
          "zip": values.billingAddress.zip,
        }
      ],
      "user_address_service_use": [
        {
          "address_line1": values.serviceAddress.address1,
          "address_line2": values.serviceAddress.address2,
          "area": values.serviceAddress.area,
          "city_name": values.serviceAddress.city_name,
          "state_name": values.serviceAddress.state_name,
          "country_name": values.serviceAddress.country_name,
          "region_name": values.serviceAddress.region_name,
          "pincode": values.serviceAddress.pincode,
          "zip": values.serviceAddress.zip,
        }
      ],
    }
    const response = onSaveContact(userData);
    
  }

  const steps = getSteps();

  return (
    <div className="w-100">
      <Stepper activeStep={activeStep} alternativeLabel className="horizontal-stepper-linear">
        {steps.map((label, index) => {
          return (
            <Step key={label} className={`horizontal-stepper ${index === activeStep ? 'active' : ''}`}>
              <StepLabel className="stepperlabel">{label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>
      <div>
        {activeStep === steps.length ? (
          <div>
            <Typography className="my-2">
              All Steps are completed - Client user created successfully
            </Typography>
            <Button onClick={handleReset}>Add New Client</Button>
          </div>
        ) : (
            <div>
              <form>
                <StepContent
                  stepIndex={activeStep}
                  formik={formik}
                />
              </form>
              <div>
                <Button
                  disabled={activeStep === 0}
                  onClick={handleBack}
                  className="mr-2"
                >
                  Back
                </Button>
                <Button variant="contained" color="primary" onClick={activeStep === steps.length - 1 ? handleSubmit : handleNext}>
                  {activeStep === steps.length - 1 ? 'Submit' : 'Next'}
                </Button>
              </div>
            </div>
          )}
        <FormikDebug props={formik} />
      </div>
    </div>
  );
}

export default UserForm;