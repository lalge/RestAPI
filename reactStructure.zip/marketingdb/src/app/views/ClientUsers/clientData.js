export const aboutList = {
  userName : {
    id: 1,
    title: 'Name',
    icon: 'face',
    userList: '',
    desc: ['']
  },
  workAt : {
    id: 2,
    title: 'Works at',
    icon: 'city-alt',
    userList: '',
    desc:['']
  },
  activeSince : {
    id: 3,
    title: 'Active Since',
    icon: 'alarm',
    userList: '',
    desc: ['']
  },
  designation : {
    id: 4,
    title: 'Designation',
    icon: 'graduation-cap',
    userList: '',
    desc: ['']
  },
  status : {
    id: 5,
    title: 'Status',
    icon: 'reorder',
    userList: '',
    desc: ['']
  }
};

export const addressList = {
  user_address_office : {
    id: 1,
    title: 'Office Address',
    icon: 'city-alt',
    userList: '',
    desc: ['']
  },
  user_address_billing : {
    id: 2,
    title: 'Billing Address',
    icon: 'balance',
    userList: '',
    desc:['']
  },
  user_address_service_use : {
    id: 3,
    title: 'Service Address',
    icon: 'pin-drop',
    userList: '',
    desc: ['']
  },
};

export const relationshipData = {
  btb_id : {
    id: 1,
    title: 'BTB Id',
    icon: 'card',
    userList: '',
    desc: ['']
  },
  user_relationship_manager_email : {
    id: 2,
    title: 'Relationship Manager Email',
    icon: 'email',
    userList: '',
    desc:['']
  },
  user_relationship_manager_name : {
    id: 3,
    title: 'Relationship Manager Name',
    icon: 'face',
    userList: '',
    desc: ['']
  },
};

export const subscriptionList = [
  // {
  //   title: '',
  //   dtName:'',
  //   industryName:'',
  //   subscriptionProduct:'',
  //   subscriptionProductType:'',
  //   subscriptionType:'',
  //   userPackageDays:'',
  //   maxPatentPerListingRegister:'',
  //   maxCompaniesPerListingRegister:'',
  //   maxProductsPerListingRegister:'',
  //   showListingTotalCount:'',
  //   startDate:'',
  //   endDate:'',
  //   analystHours:'',
  //   analystHoursUsed:'',
  // },
];


export const contactList = {
  email : {
    id: 1,
    title: 'Email',
    icon: 'email',
    desc: ['']
  },
  phone : {
    id: 3,
    title: 'Phone',
    icon: 'phone',
    desc: ['']
  },
};

export const friendList = [
  {
    id: 1,
    image: 'https://via.placeholder.com/150x150',
    name: 'Chelsea Johns',
    status: 'online'

  },
  {
    id: 2,
    image: 'https://via.placeholder.com/150x150',
    name: 'Ken Ramirez',
    status: 'offline'
  },
  {
    id: 3,
    image: 'https://via.placeholder.com/150x150',
    name: 'Chelsea Johns',
    status: 'away'

  },
  {
    id: 4,
    image: 'https://via.placeholder.com/150x150',
    name: 'Ken Ramirez',
    status: 'away'
  },
];
