import React, { useState, useEffect } from 'react';
import Chip from '@material-ui/core/Chip';
import {Link} from 'react-router-dom';
import {
    Grid,
    Table,
    TableHeaderRow,
    TableGroupRow,
    GroupingPanel,
    DragDropProvider,
    Toolbar,
    TableColumnResizing,
    TableFilterRow,
} from '@devexpress/dx-react-grid-material-ui';
import {
    DataTypeProvider,
    GroupingState,
    IntegratedGrouping,
    FilteringState,
    IntegratedFiltering,
} from '@devexpress/dx-react-grid';

const capitalize = (s) => {
    if (typeof s !== 'string') return ''
    return s.charAt(0).toUpperCase() + s.slice(1)
}

const UserNameFormatter = ({ value }) => {
    return (<Link to={"customer/"+value[1]}>{value[0]}</Link>);
}

const UserNameProvider = props => (
    <DataTypeProvider
        formatterComponent={UserNameFormatter}
        {...props}
    />
);

const StatusFormatter = ({ value }) => {
    switch (value) {
        case 'recieved':
            return (
                <Chip
                    size="small"
                    label={capitalize(value)}
                />
            );
        case 'pending':
            return (
                <Chip
                    size="small"
                    label={capitalize(value)}
                    color="primary"
                />
            );
        case 'failed':
            return (
                <Chip
                    size="small"
                    label={capitalize(value)}
                    color="secondary"
                />
            )
        default:
            return null;
    }
}



const StatusProvider = props => (
    <DataTypeProvider
        formatterComponent={StatusFormatter}
        {...props}
    />
);

const PeriodFormatter = ({ value }) => {
    // value = value.split(" To ");
    return (
        <>{value}</>
    )
}

const PeriodProvider = props => (
    <DataTypeProvider
        formatterComponent={PeriodFormatter}
        {...props}
    />
)

const SubscriptionHistoryGrid = (props) => {
    const [columns] = useState([
        { name: 'userName', title: 'User Name' },
        { name: 'amount', title: 'Amount' },
        { name: 'paymentStatus', title: 'Status' },
        { name: 'subscriptionName', title: 'Subscription Name' },
        { name: 'subscriptionProduct', title: 'Product' },
        { name: 'subscriptionPeriod', title: 'Subscription Period' },
    ]);
    const [rowData, setRowData] = useState([]);
    const [grouping, setGrouping] = useState([]);
    const [columnWidths, setColumnWidths] = useState([
        { columnName: 'userName', width: 180 },
        { columnName: 'amount', width: 80 },
        { columnName: 'paymentStatus', width: 100 },
        { columnName: 'subscriptionName', width: 180 },
        { columnName: 'subscriptionProduct', width: 140 },
        { columnName: 'subscriptionPeriod', width: 240 },
    ]);

    useEffect(() => {
        setRowData(props.rowData);
    }, [props.rowData]);

    return (

        <Grid
            rows={rowData}
            columns={columns}
        >

            <DragDropProvider />
            <GroupingState
                grouping={grouping}
                onGroupingChange={setGrouping}
            />
            <IntegratedGrouping />
            <StatusProvider
                for={['paymentStatus']}
            />
            <PeriodProvider
                for={['subscriptionPeriod']}
            />
            <UserNameProvider
                for={['userName']}
            />
            <FilteringState defaultFilters={[]} />
            <IntegratedFiltering />
            <Table />
            <TableColumnResizing
                columnWidths={columnWidths}
                onColumnWidthsChange={setColumnWidths}
            />
            <TableHeaderRow />
            <TableGroupRow />
            <TableFilterRow />
            <Toolbar />
            <GroupingPanel showGroupingControls />
        </Grid>

    );
};
export default SubscriptionHistoryGrid;