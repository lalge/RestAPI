import React, { useState, useEffect } from 'react';
import CardBox from '../../components/CardBox/index';
import { SubscriptionApi, getAllSubscriptionHistory } from '../../../store/middelware/api/Subscription'
import { UserApi, getAllClientUsers } from '../../../store/middelware/api/UsersApi';
import CircularProgress from '../../components/CircularProgress';
import Snackbar from '@material-ui/core/Snackbar';
import SubscriptionHistoryGrid from './SubscriptionHistoryGrid';
import {getDateFromMongoDate} from '../../../utilities/utilities';

const Listing = () => {

  const [rowData, setRowData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [showMessage, setShowMessage] = useState(false);


  const handleRequestClose = () => {
    setShowMessage(false);
  };

  useEffect(() => {
    setLoading(true);
    const subscription = SubscriptionApi(getAllSubscriptionHistory);
    const ClientData = UserApi(getAllClientUsers);
    Promise.all([subscription, ClientData])
      .then((response) => {
        setLoading(false);
        try {
          const allSubscriptionData = response[0];
          const allClientData = response[1];
          let filterClient = [];
          const processSubscriptionData = [];
          if (allSubscriptionData.status === 200 || allClientData.status === 200) {
            allSubscriptionData.data.forEach((element, index) => {
              filterClient = allClientData.data.filter((clientElement) => {
                // if(clientElement._id=== element.user_id){
                //   allClientData.data.splice(clientIndex, 1);
                // }
                return clientElement._id === element.user_id;
              })
              if (filterClient.length > 0) {
                allSubscriptionData.data[index].user_name = filterClient[0].user_fname + " " + filterClient[0].user_lname;
              }
              processSubscriptionData.push({
                userName: [filterClient[0].user_fname + " " + filterClient[0].user_lname,filterClient[0]._id],
                amount: element.payment_details.amount || '0',
                paymentStatus: element.payment_details.payment_status,
                subscriptionName: element.subscription_name,
                subscriptionProduct: element.subscription_product_services.product_name,
                subscriptionPeriod: getDateFromMongoDate(element.subscription_start_date) + " To " + getDateFromMongoDate(element.subscription_end_date)
              });
            });
            setRowData(processSubscriptionData);
          } else {
            throw Object.assign(
              new Error("SOMETHING WENT WRONG"),
              { code: 500 }
            );
          }

        }
        catch (err) {
          console.log("SOMETHING WENT WRONG WHILE PROCESSING", err);
          setShowMessage(true);
          setAlertMessage("SOMETHING WENT WRONG WHILE PROCESSING");
        }


      })
      .catch((e) => {
        setLoading(false);
        setShowMessage(true);
        setAlertMessage("ERROR WHILE FETCHING SUBSCRIPTION");
        console.log("ERROR WHILE FETCHING SUBSCRIPTION", e);
      })
  }, []);

  return (
    <div className="app-wrapper">
      <div className="animated slideInUpTiny animation-duration-3">

        <div className="row" style={{ overflowY: 'auto' }}>
          <CardBox
            styleName="col-lg-12"
            heading="Subscription History"
            headingStyle="text-center"
          >
            {
              loading ?
                <div className="loader-view-block h-100">
                  <div className="loader-view">
                    <CircularProgress />
                  </div>
                </div> :
                <SubscriptionHistoryGrid
                  rowData={rowData}
                />
            }

          </CardBox>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={showMessage}
        autoHideDuration={5000}
        onClose={handleRequestClose}
        ContentProps={{
          'aria-describedby': 'message-id',
        }}
        message={<span id="message-id">{alertMessage}</span>}
      />
    </div>
  );
};
export default Listing;