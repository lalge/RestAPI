const galleryData = [
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Breakfast',
  },

  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Honey',
  },
  {
    img: 'https://via.placeholder.com/500x350',
    title: 'Vegetables',
  },

  {
    img: 'https://via.placeholder.com/500x375',
    title: 'Olive oil',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Blue Bird',
  },
  {
    img: 'https://via.placeholder.com/500x330',
    title: 'Morning',
  },

];

export default galleryData;
