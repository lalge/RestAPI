import React from 'react';
import TextField from '@material-ui/core/TextField';
const  PersonalInformation = props => {
    const { formik } = props;
    return <div>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              required
              name="firstName"
              label="First Name"
              margin="normal"
              autoComplete='off'
              error={typeof formik.errors.firstName !== 'undefined' && formik.touched.firstName === true}
              helperText={formik.touched.firstName === true ? formik.errors.firstName || '' : ''}
              {...formik.getFieldProps('firstName')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              required
              name="lastName"
              label="Last Name"
              margin="normal"
              autoComplete='off'
              error={typeof formik.errors.lastName !== 'undefined' && formik.touched.lastName === true}
              helperText={formik.touched.lastName === true ? formik.errors.lastName || '' : ''}
              {...formik.getFieldProps('lastName')}
              fullWidth
            />
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              required
              name="email"
              label="Buisnaess Email"
              margin="normal"
              autoComplete='off'
              error={typeof formik.errors.email !== 'undefined' && formik.touched.email === true}
              helperText={formik.touched.email === true ? formik.errors.email || '' : ''}
              {...formik.getFieldProps('email')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Contact Number"
              name="phone"
              margin="normal"
              error={typeof formik.errors.phone !== 'undefined' && formik.touched.phone === true}
              helperText={formik.touched.phone === true ? formik.errors.phone || '' : ''}
              {...formik.getFieldProps('phone')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Password"
              name="password"
              margin="normal"
              autoComplete='off'
              error={typeof formik.errors.password !== 'undefined' && formik.touched.password === true}
              helperText={formik.touched.password === true ? formik.errors.password || '' : ''}
              {...formik.getFieldProps('password')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Confirm Password"
              name="confirmPassword"
              margin="normal"
              autoComplete='off'
              type="password"
              error={typeof formik.errors.confirmPassword !== 'undefined' && formik.touched.confirmPassword === true}
              helperText={formik.touched.confirmPassword === true ? formik.errors.confirmPassword || '' : ''}
              {...formik.getFieldProps('confirmPassword')}
              fullWidth
            />
          </div>
        </div>
      </div>
    </div>
  }
  export default PersonalInformation;
  