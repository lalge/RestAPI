import React from 'react';
import TextField from '@material-ui/core/TextField';
const AddressInformation = props => {
    const { formik } = props;
    return <div>
      <h3 className="title text-primary text-center">Billing Address</h3>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Billing Address (Street,Building)"
              name="billingAddress.address1"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('billingAddress.address1')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Billing Address (Landmark)"
              name="billingAddress.address2"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('billingAddress.address2')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Area"
              margin="normal"
              autoComplete='off'
              name="billingAddress.area"
              {...formik.getFieldProps('billingAddress.area')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="City"
              margin="normal"
              autoComplete='off'
              name="billingAddress.city_name"
              {...formik.getFieldProps('billingAddress.city_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="State"
              margin="normal"
              autoComplete='off'
              name="billingAddress.state_name"
              {...formik.getFieldProps('billingAddress.state_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Pincode"
              margin="normal"
              autoComplete='off'
              name="billingAddress.pincode"
              {...formik.getFieldProps('billingAddress.pincode')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Country"
              margin="normal"
              autoComplete='off'
              name="billingAddress.country_name"
              {...formik.getFieldProps('billingAddress.country_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Telephone"
              margin="normal"
              autoComplete='off'
              name="billingAddress.telphone"
              {...formik.getFieldProps('billingAddress.telphone')}
              fullWidth
            />
          </div>
        </div>
      </div>
      <br />
      <h3 className="title text-primary text-center">Service Address</h3>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Service Address (Street,Building)"
              name="serviceAddress.address1"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('serviceAddress.address1')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Service Address (Landmark)"
              name="serviceAddress.address2"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('serviceAddress.address2')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Area"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.area"
              {...formik.getFieldProps('serviceAddress.area')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="City"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.city_name"
              {...formik.getFieldProps('serviceAddress.city_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="State"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.state_name"
              {...formik.getFieldProps('serviceAddress.state_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Pincode"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.pincode"
              {...formik.getFieldProps('serviceAddress.pincode')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Country"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.country_name"
              {...formik.getFieldProps('serviceAddress.country_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Telephone"
              margin="normal"
              autoComplete='off'
              name="serviceAddress.telphone"
              {...formik.getFieldProps('serviceAddress.telphone')}
              fullWidth
            />
          </div>
        </div>
      </div>
    </div>
  
  }
export default AddressInformation;  