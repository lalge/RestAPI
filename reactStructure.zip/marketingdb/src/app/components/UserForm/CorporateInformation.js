import React from 'react';
import TextField from '@material-ui/core/TextField';
const CorporateInformation = props => {
    const { formik } = props;
    return <div>
      <div className="row">
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Designation"
              name="designation"
              margin="normal"
              autoComplete='off'
              {...formik.getFieldProps('designation')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              required
              name="company"
              label="Company Name"
              margin="normal"
              autoComplete='off'
              {...formik.getFieldProps('company')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Office Address (Street,Building)"
              name="officeAddress.address1"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('officeAddress.address1')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Office Address (Landmark)"
              name="officeAddress.address2"
              margin="normal"
              fullWidth
              {...formik.getFieldProps('officeAddress.address2')}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="Area"
              margin="normal"
              autoComplete='off'
              name="officeAddress.area"
              {...formik.getFieldProps('officeAddress.area')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-group">
            <TextField
              label="City"
              margin="normal"
              autoComplete='off'
              name="officeAddress.city_name"
              {...formik.getFieldProps('officeAddress.city_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="State"
              margin="normal"
              autoComplete='off'
              name="officeAddress.state_name"
              {...formik.getFieldProps('officeAddress.state_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Pincode"
              margin="normal"
              autoComplete='off'
              name="officeAddress.pincode"
              {...formik.getFieldProps('officeAddress.pincode')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Country"
              margin="normal"
              autoComplete='off'
              name="officeAddress.country_name"
              {...formik.getFieldProps('officeAddress.country_name')}
              fullWidth
            />
          </div>
        </div>
        <div className="col-md-3">
          <div className="form-group">
            <TextField
              label="Telephone"
              margin="normal"
              autoComplete='off'
              name="officeAddress.telphone"
              {...formik.getFieldProps('officeAddress.telphone')}
              fullWidth
            />
          </div>
        </div>
      </div>
    </div>
  
  }

  export default CorporateInformation;