import React from 'react';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

const StakeholdersInformation = props => {
    const { formik } = props;
    return <div>
        <div className="row">
            <div className="col-md-6">
                <div className="form-group">
                    <TextField
                        required
                        label="BTB Id"
                        margin="normal"
                        autoComplete='off'
                        name="btbId"
                        {...formik.getFieldProps('btbId')}
                        fullWidth
                    />
                </div>
            </div>
            <div className="col-md-6">
                <div className="form-group">
                    <TextField
                        required
                        label="Relationship Manager Name"
                        margin="normal"
                        autoComplete='off'
                        name="relationshipManagerName"
                        {...formik.getFieldProps('relationshipManagerName')}
                        fullWidth
                    />
                </div>
            </div>
            <div className="col-md-6">
                <div className="form-group">
                    <TextField
                        required
                        label="Relationship Manager Email"
                        margin="normal"
                        autoComplete='off'
                        name="relationshipManagerEmail"
                        {...formik.getFieldProps('relationshipManagerEmail')}
                        fullWidth
                    />
                </div>
            </div>
            <div className="col-md-6">
                <div className="form-group">
                    <FormControl style={{ width: '100%' }} margin="normal">
                        <InputLabel id="status-label">Status</InputLabel>
                        <Select
                            required
                            labelId="status-label"
                            name="userStatus"
                            {...formik.getFieldProps('userStatus')}
                        >
                            <MenuItem value={1}>Active</MenuItem>
                            <MenuItem value={0}>In-active</MenuItem>
                        </Select>
                    </FormControl>
                </div>
            </div>

        </div>
    </div>
}
export default StakeholdersInformation;  