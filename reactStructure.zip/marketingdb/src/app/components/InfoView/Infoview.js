import React, { useEffect, useState } from 'react';
import CircularProgress from "../CircularProgress/index";
import Snackbar from '@material-ui/core/Snackbar';
import Auxiliary from "../../../utilities/Auxiliary";

const InfoView = props => {
  
  // const { error, loading, message,alignment } = props;
  
  const [message, setMessage] = useState(props.message);
  const [loading, setLoading] = useState(props.loading);
  const [alignment] = useState(props.alignment || 'top');
  console.log(alignment);
  useEffect(() => {
    setLoading(props.loading);
    setMessage(props.message);
  }, [props.message,props.loading]);
  return (
    <Auxiliary>
      {loading && <div className="loader-view">
      {props.children}
        <CircularProgress />
      </div>}
      <Snackbar
        anchorOrigin={{ vertical: alignment, horizontal: 'center' }}
        open={message !== ''}
        autoHideDuration={3000}
        ContentProps={{
          'aria-describedby': 'message-id',
        }}
        message={<span id="message-id">{message}</span>}
      />
    </Auxiliary>
  );
}

export default InfoView;