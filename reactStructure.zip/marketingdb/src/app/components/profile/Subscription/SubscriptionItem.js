import React from "react";

function SubscriptionItem({ data }) {
  const {
    title,
    dtName,
    industryName,
    subscriptionProductType,
    subscriptionType,
    userPackageDays,
    maxPatentPerListingRegister,
    maxCompaniesPerListingRegister,
    maxProductsPerListingRegister,
    showListingTotalCount,
    startDate,
    endDate,
    analystHours,
    analystHoursUsed
  } = data;

  return (
    <div className="media jr-featured-item">

      <div className="media-body jr-featured-content">
        <div className="jr-featured-content-left">
          <h3 className="mb-2">{title}</h3>
          <div className="row-flex">
            {dtName !== '' ? <p>DT Name : {dtName}</p> : null}
            {industryName !== '' ? <p>Industry Name : {industryName}</p> : null}
            {subscriptionType !== '' ? <p>Subscription Type : {subscriptionType}</p> : null}
            {startDate !== '' ? <p>Start Date : {startDate}</p> : null}
            {endDate !== '' ? <p>End Date : {endDate}</p> : null}
            {subscriptionProductType !== '' ? <p>Subscription Product Type : {subscriptionProductType}</p> : null}
            {analystHours !== '' ? <p>Analyst Hours : {analystHours}</p> : null}
            {analystHoursUsed !== '' ? <p>Analyst Hours Used : {analystHoursUsed}</p> : null}
          </div>
        </div>
        {subscriptionProductType !== 'analyst' ?
          <div className="jr-featured-content-right jr-profile-content-right">
            <h2 className="text-primary mb-1">
            <i className={`zmdi zmdi-calendar jr-fs-lg mr-2 d-inline-flex align-middle`}/>
              End Date : <span className="d-inline-flex align-middle">{endDate}</span>
            </h2>
            <div className="row-flex">
              {userPackageDays !== '' ? <p>User Package Days : {userPackageDays}</p> : null}
              {maxPatentPerListingRegister !== '' ? <p>Max Patent Per Listing Register : {maxPatentPerListingRegister}</p> : null}
              {maxCompaniesPerListingRegister !== '' ? <p>Max Companies Per Listing Register : {maxCompaniesPerListingRegister}</p> : null}
              {maxProductsPerListingRegister !== '' ? <p>Max Products Per Listing Register : {maxProductsPerListingRegister}</p> : null}
              {showListingTotalCount !== '' ? <p>Show Listing Total Count : {showListingTotalCount}</p> : null}
            </div>
          </div>
          : null}

      </div>
    </div>
  );
}

export default SubscriptionItem;
