import React from "react";

import Widget from "../../Widget/index";
import SubscriptionItem from "./SubscriptionItem";

const Subscription = (props) => {
  const {subscriptionList} = props;
  return (
    <Widget styleName="jr-card-profile">
      <div className="mb-3 mb-md-2">
        <h3 className="card-title mb-2 mb-md-3">Subscription</h3>
      </div>
      <div className="pt-md-3">
        {subscriptionList.map((data, index) =>
          <SubscriptionItem key={index} data={data}/>
        )}
      </div>
    </Widget>
  );
}

export default Subscription;
