const config = {
    apiConfig:{
        apiUrl:"http://localhost:3000/",
        apiAuth:{
            api_auth_username:'admin@futurebridge.com',
            api_auth_password:'123'
        },
        applicationKey:"b7611e1d16e3c113ef9bf7816ed13a317f0e5356",
        urlConfig : {
            authenticateUser : 'authenticate',
            getAllClientUsers : 'customers',
            getClientUser:'customers/{customerId}',
            getAllSubscriptionHistory : 'subscriptions/history',
            createClientUser:'customers'
        }
    }
}

export default config;