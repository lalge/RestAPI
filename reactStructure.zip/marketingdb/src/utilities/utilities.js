export const getDateFromMongoDate = (date)=>{
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    let newDate = new Date(date);
    newDate = newDate.getDate() + "-" + months[newDate.getMonth()] + "-" + newDate.getFullYear();
    return newDate;
}