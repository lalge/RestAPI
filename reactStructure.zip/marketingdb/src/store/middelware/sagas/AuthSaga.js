import { takeLatest, call, put, fork } from 'redux-saga/effects';
import { SIGNIN_USER,SIGNOUT_USER } from '../../../app/constants/ActionTypes';
import { fetchStart, fetchSuccess, fetchError } from '../../actions/Common';
import {user_token_set,user_data,signout_user_success} from '../../actions/Auth.action'
import * as usersApi from '../api/UsersApi';
import axios from '../api/ApiInit';
function* authenticateUser({payload}) {
    try {
        const email = payload.email;
        const password = payload.password;
        yield put(fetchStart());
        const result = yield call(usersApi.authenticateUser, { email, password});
        console.log("DATATOKEN",result.data.token);
        if (typeof result.data.token != 'undefined') {
            localStorage.setItem("token", JSON.stringify(result.data.token));
            axios.defaults.headers.common['Authorization'] = "Bearer " + result.data.token;
            yield put(fetchStart());
            yield put(user_token_set(result.data.token));
            yield put(user_data(''));
        } else {
            yield put(fetchError(result.data.error));
        }
        yield put(fetchSuccess());
    } catch (e) {
        yield put(fetchError("NETWORK ERROR : Unable to handle request"));
        console.log("ERROR WHILE FETCHING CLIENT USER", e);
    }
}

function* userSignOut(){
    try{
        console.log("userSignOut");
        localStorage.removeItem("token");
        yield put(signout_user_success());
    } catch(e){

    }
}

function* watchAuthenticateUser() {
    yield takeLatest(SIGNIN_USER, authenticateUser);
}

function* watchUserSignOut(){
    yield takeLatest(SIGNOUT_USER,userSignOut);
}

const authSagas = [
    fork(watchAuthenticateUser),
    fork(watchUserSignOut)
];

export default authSagas;