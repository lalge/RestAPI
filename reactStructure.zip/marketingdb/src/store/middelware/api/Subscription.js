import axios from "./ApiInit";
import config from "../../../config";
import { authenticateApi } from "./ApiAuth";

const getAllSubscriptionHistory = () => {
    return axios.get(config.apiConfig.urlConfig.getAllSubscriptionHistory);
}


const SubscriptionApi = async (callback, param = {}) => {
    try {
        if (Object.keys(param).length) {
            const callbackResult = await callback(param);
            return callbackResult;
        } else {
            const callbackResult = await callback();
            return callbackResult;
        }
    } catch (e) {
        if (e.response.status === 401) {
            await authenticateApi();
            if (Object.keys(param).length) {
                const callbackResult = await callback(param);
                return callbackResult;
            } else {
                const callbackResult = await callback();
                return callbackResult;
            }
        }
    }
}
export {
    SubscriptionApi,
    getAllSubscriptionHistory
};