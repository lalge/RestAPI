import axios from 'axios';
import config from '../../../config';
export default axios.create({
  baseURL: config.apiConfig.apiUrl,//YOUR_API_URL HERE
  headers: {
    'Content-Type': 'application/json',
  }
});
