import axios from "./ApiInit";
import config from "../../../config";
import { authenticateApi } from "./ApiAuth";
const authenticateUser = ({ email, password }) => {
    return axios.post(config.apiConfig.urlConfig.authenticateUser, {
        api_auth_username: email,
        api_auth_password: password,
        auth_application_key: config.apiConfig.applicationKey
    })
};
const getAllClientUsers = () => {
    return axios.get(config.apiConfig.urlConfig.getAllClientUsers);
}

const createClientUser = (param = '') => {
    return axios.post(config.apiConfig.urlConfig.createClientUser,param);
}

const getClientUsers = (param = '') => {
    return axios.get(config.apiConfig.urlConfig.getClientUser+"?"+param);
}


const UserApi = async (callback, param = {}) => {
    try {
        if (Object.keys(param).length) {
            const callbackResult = await callback(param);
            return callbackResult;
        } else {
            const callbackResult = await callback();
            return callbackResult;
        }
    } catch (e) {
        if (e.response.status === 401) {
            await authenticateApi();
            if (Object.keys(param).length) {
                const callbackResult = await callback(param);
                return callbackResult;
            } else {
                const callbackResult = await callback();
                return callbackResult;
            }
        }
    }
}
export {
    getAllClientUsers,
    getClientUsers,
    authenticateUser,
    createClientUser,
    UserApi
};