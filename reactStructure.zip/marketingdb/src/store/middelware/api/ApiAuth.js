import axios from './ApiInit'
import config from "../../../config";

const authenticateApi = async () => {
    try {
        const authResult = await axios.post(config.apiConfig.urlConfig.authenticateUser, {
            api_auth_username: config.apiConfig.apiAuth.api_auth_username,
            api_auth_password: config.apiConfig.apiAuth.api_auth_password,
            auth_application_key: config.apiConfig.applicationKey
        });
        if (typeof authResult.data.token != 'undefined') {
            axios.defaults.headers.common['Authorization'] = "Bearer " + authResult.data.token;
            return authResult.data.token;
        }
        return '';
    }
    catch (e) {
        console.log("UNAUTHORIZE REQUEST");
    }
};

export { authenticateApi };