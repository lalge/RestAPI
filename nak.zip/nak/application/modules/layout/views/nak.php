<h1>Main template</h1>
<?php 
echo $this->load->view($content_view);
?>