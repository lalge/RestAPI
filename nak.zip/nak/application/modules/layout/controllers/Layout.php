<?php

class Layout extends MY_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {        
    }
    
    function nak($data = NULL){
        $this->load->view('layout/nak', $data);
    }
    
}
