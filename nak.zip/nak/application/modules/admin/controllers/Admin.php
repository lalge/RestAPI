<?php

class Admin extends MY_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        echo "All about";
    }
    
    function great(){
        $data['content_view'] = 'admin/great';
        $this->layout->nak($data);
    }

}
