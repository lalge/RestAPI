// This will load our .env file and add the values to process.env,
// IMPORTANT: Omit this line if you don't want to use this functionality
require('dotenv').config({silent: true});

module.exports = {
  port: process.env.PORT || 3000,
  host: process.env.HOST || 3000,
  env: process.env.ENV || 'development',
  mongoDbUri:process.env.MONGO_DB_URI  
};
