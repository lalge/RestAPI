var settings = require('./settings');
module.exports = settings;