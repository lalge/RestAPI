//import the Mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;


const LogApiSchema = new Schema({
    request_date: {
        type: Date
    },
    request_params: {
        type: Object
    },
    request_api:{
        type:String
    },
    response_count: {
        type: Number
    },
}, {
    versionKey: false // You should be aware of the outcome after set to false
});

module.exports = Mongoose.model('gnx_log_api', LogApiSchema, 'gnx_log_api');