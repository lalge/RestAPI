const soapService = require('../../services/soapService');
const _ = require('underscore');

module.exports = {
    getBTB: async (req) => {

        const BTBs = await soapService.soapCall({
            appName: 'BDSystem',
            soapMethod: 'getTrialRunBTB',
            parameters: {
                pType: 'viewbtb',
                pEmpCode: req.query.employeeCode
            }
        });
        if(BTBs['getTrialRunBTBResult']){
            return BTBs['getTrialRunBTBResult']['clsTRBTB'];
        }else{
            return [];
        }
    },
    createBTB: async (req) => {
        
        const BTBs = await soapService.soapCall({
            appName: 'BDSystem',
            soapMethod: 'getTrialRunBTB',
            parameters: {
                pType: 'createnew',
                pEmpCode: req.payload.employeeCode,
                pCompName: req.payload.companyName,
                pFname: req.payload.contactFName,
                pLname: req.payload.contactLName,
                pEmail: req.payload.contactEmail,
            }
        });
        if(BTBs['getTrialRunBTBResult']){
            return BTBs['getTrialRunBTBResult']['clsTRBTB'][0]['p_iU_BTB_ID'];
        }else{
            return [];
        }
    },
    getMeetingContacts : async (req) => {

        const meetingContacts = await soapService.soapCall({
            appName: 'BDSystem',
            soapMethod: 'getMeetingData',
            parameters: {
                pCode: '#$34F5',
                pPNL: req.query.PNL,
                pSdate: req.query.fromDate,
                pEdate: req.query.toDate,
            }
        });
        if(meetingContacts['getMeetingDataResult']){
            return meetingContacts['getMeetingDataResult']['clsMeetinginfo'];
        }else{
            return [];
        }
        
    },
};