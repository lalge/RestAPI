//Users.routes.js
const BdsystemController = require('../controllers/bdsystem.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
const _ = require('underscore');
module.exports = [ 
    {
        path: '/bdsystem/btb',
        method: 'POST',
        options: {
            description: 'Create New BTB in BD System, System will Use BD System SOAP Call to create BTB',
            notes: "Returns BTB Id on succesfully creation.",
            tags: ['api'],
            // plugins: {
            //     'hapi-swagger': {
            //         payloadType: 'form'
            //     }
            // },
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    employeeCode: Joi.string().min(1).max(50).required().description('Employee code of person who is responsible to create BTB'),
                    companyName: Joi.string().allow('').description('Company name of BTB'),
                    contactFName: Joi.string().required().description('Contact\'s first name'),
                    contactLName: Joi.string().required().description('Contact\'s last name'),
                    contactEmail: Joi.string().required().email().description('Contact\'s email id'),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await BdsystemController.createBTB(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }

    },
    {
        path: '/bdsystem/btb',
        method: 'GET',
        options: {
            description: 'Get BTB list',
            notes: "Returns an array of BTB with details ",
            tags: ['api'],
            validate: {
                query: {
                    employeeCode: Joi.string().min(1).max(50).required().description('Employee code of person'),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await BdsystemController.getBTB(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/bdsystem/meeting-contacts',
        method: 'GET',
        options: {
            description: 'Get Meeting Contact list from BD System',
            notes: "Returns an array of Contact ",
            tags: ['api'],
            validate: {
                query: {
                    PNL: Joi.number().required().description('PNL is the Service Division Id of BD System'),
                    fromDate: Joi.string().required().description('Contact created from date'),
                    toDate: Joi.string().required().description('Contact created till date'),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await BdsystemController.getMeetingContacts(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    }
];