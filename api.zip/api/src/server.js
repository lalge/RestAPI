'use strict';

// use for setting different environment e.g production, develpoemnt, stage
require('dotenv').config({ path: './config/.env' });

const Hapi = require('hapi');

// for API documentation
const HapiSwagger = require('hapi-swagger');
// used to generate static html of swagger documentation
const Inert = require('inert');
// used to create template and decorates  swagger documentation
const Vision = require('vision');

// for error handling presentation
const Boom = require('boom');

// Custom/Global function
const Functions = require('../libs/function');

// Include custom routes
const Routes = require('./default/routes');

// Centerlized DB connectivity
const Db = require('../database');

// Handlebars
const Handlebars = require('handlebars');
const HandlebarsHelpers = require('handlebars-helpers').array();
// register HandlebarsHelpers
if (HandlebarsHelpers) {
    for (let key in HandlebarsHelpers) {
        if (key) {
            // console.log('key', key, helpers[key]);
            Handlebars.registerHelper(key, HandlebarsHelpers[key]);
        }
    }
}
// http://bdadam.com/blog/comparison-helper-for-handlebars.html 
Handlebars.registerHelper('ifCond', function (v1, operator, v2, options) {
    switch (operator) {
        case '==':
            return (v1 == v2) ? options.fn(this) : options.inverse(this);
        case '===':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '!==':
            return (v1 !== v2) ? options.fn(this) : options.inverse(this);
        case '<':
            return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=':
            return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>':
            return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=':
            return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&':
            return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||':
            return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default:
            return options.inverse(this);
    }
});
(async () => {
    const server = await new Hapi.Server({
        host: process.env.HOST,
        port: process.env.PORT,
        routes: { cors: true }
    });

    //  register swagger
    await server.register([
        Inert,
        Vision,
        {
            plugin: HapiSwagger,
            options: {
                info: {
                    title: 'API Documentation',
                    version: 'v1',
                },
            }
        }
    ]);

    // register jwt 
    await server.register(require('hapi-auth-jwt2'));

    server.auth.strategy('jwt', 'jwt',
        {
            key: process.env.JWT_SECRET,         // Never Share your secret key
            validate: Functions.verifyToken,            // validate function defined above
            verifyOptions: { algorithms: ['HS256'] } // pick a strong algorithm
        });

    server.auth.default('jwt');



    try {

        // set view settings
        // server.views({
        //     engines: {
        //         html: require('handlebars')
        //     },
        //     relativeTo: __dirname,
        //     path: './templates/views',
        //     layoutPath:'./templates/layout',
        //     helpersPath: './templates/helpers'
        // });


        await server.start();
        // set route prefix from config
        // console.dir(process.env);  
        // server.realm.modifiers.route.prefix = process.env.ROUTE_PREFIX,
        console.log('Server running at:', server.info.uri);
        server.route(Routes);

    } catch (err) {
        console.log(err);
    }


})();
