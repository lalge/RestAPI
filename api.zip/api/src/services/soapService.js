require('dotenv').config({ path: '../../config/.env' });
const _ = require('underscore');
const request = require('request')

/**
 * @description Open DB connection to Remote Application 
 * @param {*} params 
 */
function getSoapURI(params) {
    let soapURI = '';
    if (params.appName == 'BDSystem') {
        if (process.env.BD_SYSTEM_API_URI) {
            soapURI = process.env.BD_SYSTEM_API_URI;
        }
    }
    if (soapURI != '') {
        return soapURI;
    } else {
        return false;
    }
}
function soapCall(params) {
    try {
        let connectionUrl = getSoapURI(params);
        if (connectionUrl === false) {
            return { error: 'connectionURI not set' };
        }
        if (!params.soapMethod) {
            return { error: 'soapMethod not set' };
        }
        if (!_.isObject(params.parameters)) {
            return { error: 'parameters not set or it\'s not an Object' };
        }
        const soap = require('soap');

        if (process.env.BD_BRIDGE_SERVER_URI !== '') {
            // call through Local BRIDGE URI if set
            let postParam = {
                function: params.soapMethod,
                parameters: params.parameters,
                bdSoapUrl: connectionUrl
            };
            return new Promise((resolve, reject) => {
                request({
                    url: process.env.BD_BRIDGE_SERVER_URI,
                    json: true,
                    method: 'POST',
                    body: postParam,
                    timeout: 30000
                }, (error, res, body) => {
                    if (!error && res.statusCode == 200) {
                        resolve(body);
                    } else {
                        reject(error);
                    }
                });
            });
        } else {
            return new Promise((resolve, reject) => {
                soap.createClient(connectionUrl, (err, client) => {
                    client[params.soapMethod](params.parameters, (err, result, body) => {
                        if (!err) {
                            resolve(result);
                        } else {
                            reject(error);
                        }

                    })
                });
            });
        }

    } catch (err) {
        throw err;
        // return { "error": "Error in connection to DB" };
    }

}

const soapService =
{
    soapCall: soapCall,
};
module.exports = soapService;