/**
 * Get Data from Remote App DB
 */
require('dotenv').config({ path: '../../config/.env' });
const MongoClient = require('mongodb').MongoClient;


/**
 * @description Open DB connection to Remote Application 
 * @param {*} params 
 */
function connectToRemoteAppDb(params) {
    let remoteAppDbURI = '';
    if (params.remoteAppName == 'whatnext') {
        if (process.env.MONGO_DB_URI_WHATNEXT) {
            remoteAppDbURI = process.env.MONGO_DB_URI_WHATNEXT;
        }
    } else if (params.remoteAppName == 'industryinsider') {
        if (process.env.MONGO_DB_URI_INDUSTRYINSIDER) {
            remoteAppDbURI = process.env.MONGO_DB_URI_INDUSTRYINSIDER;
        }
    } else if (params.remoteAppName == 'whatnext_cms') {
        if (process.env.MONGO_DB_URI_WHATNEXT_CMS) {
            remoteAppDbURI = process.env.MONGO_DB_URI_WHATNEXT_CMS;
        }
    }
    if (params.storageName == '') {
        return { error: 'storageName not set' };
    }
    if (params.dbMethod == '') {
        return { error: 'dbMethod not set' };
    }
    if (remoteAppDbURI != '') {
        return remoteAppDbURI;
    } else {
        return false;
    }
}
/**
 * @description Get Data from Remote Application Database
 * @param params
 *  {
 *      remoteAppName: 'whatnext', // whatnext, industryinsider
        storageName: 'inx_user',
        dbMethod: 'mongoFind', //mongoFind, mongoAggregate
        where: { user_email: req.query.user_email },
 * }
 *  
 */
async function getDataFromRemoteAppDb(params) {
    try {
        let connectionUrl = connectToRemoteAppDb(params);
        if (connectionUrl === false) {
            return { error: 'connectionURI not set' };
        }
        const client = await MongoClient.connect(connectionUrl,
            {
                useNewUrlParser: true,
                useUnifiedTopology: true
            });
        const db = client.db();

        var result = [];
        if (params.dbMethod == 'mongoFind') {
            let where = {};
            if (params.where == '') {
                return { error: 'where not set' };
            }
            where = params.where;
            result = await db.collection(params.storageName).find(where).toArray();
        } else if (params.dbMethod == 'mongoAggregate') {
            let pipeline = [];
            if (params.pipeline == '') {
                return { error: 'pipeline not set' };
            }
            pipeline = params.pipeline;
            result = await db.collection(params.storageName).aggregate(pipeline).toArray();
        }
        client.close();
        return result;
    } catch (err) {
        return { "error": "Error in connection to DB" };
    }

}
/**
 * @description Set Data in Remote Application Database
 * @param params
 *  {
 *      remoteAppName: 'whatnext', // whatnext, industryinsider
        storageName: 'inx_user', // collection name
        dbMethod: 'mongoUpdate', // mongoUpdate, mongoInsert
        where: { user_email: req.query.user_email },
        data: { $set: { user_company: 'Cheers' } }
 * }
 *  
 */
async function setDataInRemoteAppDb(params) {
    try {
        let connectionUrl = connectToRemoteAppDb(params);
        if (connectionUrl === false) {
            return { error: 'connectionURI not set' };
        }
        const client = await MongoClient.connect(connectionUrl,
            {
                useNewUrlParser: true,
                useUnifiedTopology: true
            });
        const db = client.db();
        var result = [];
        if (params.dbMethod == 'mongoUpdate') {
            let where, data = {};
            if (params.where == '') {
                return { error: 'where not set' };
            }
            if (params.data == '') {
                return { error: 'data not set' };
            }
            where = params.where;
            data = params.data;
            result = await db.collection(params.storageName).updateOne(where, data);
        } else if (params.dbMethod == 'mongoInsert') {
            let data = [];
            if (params.data == '') {
                return { error: 'data not set' };
            }
            data = params.data;
            result = await db.collection(params.storageName).insertOne(data);
        }
        client.close();
        return result;
    } catch (err) {
        return { "error": "Error in connection to DB" };
    }

}
const remoteAppDbService =
{
    getDataFromRemoteAppDb: getDataFromRemoteAppDb,
    setDataInRemoteAppDb: setDataInRemoteAppDb
};
module.exports = remoteAppDbService;