//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;

// const CompanySchema = new Schema({
//     name: {
//         required: true,
//         type: String
//     },
//     city: String,
//     address: String
// });

module.exports = Mongoose.model('inx_company', Mongoose.Schema(),'inx_company');