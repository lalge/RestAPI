//company.controller.js
const Company = require('../models/company.model');
const LogApiModel = require('../../logs/models/log-api.model');
const Functions = require('../../../libs/function');
const _ = require('underscore');
const fs = require('fs');

module.exports = {
    find: async (req) => {
        var search_keyword = '"' + Functions.escapeRegExp(req.query.search_keyword) + '"';

        var pipeline = [];
        var where = { $text: { $search: search_keyword } };
        var limit = (typeof req.query.page !== 'undefined') ? parseInt(req.query.page) : 100;

        if (req.query.industry_name) {
            var keywords = _.map(req.query.industry_name.split('|'), function (num) {
                return '\\b' + Functions.escapeRegExp(num) + '\\b';
            });
            where['company_industry.industry_name'] = new RegExp(keywords.join('|'), 'i');
        }
        if (req.query.trend_name) {
            var keywords = _.map(req.query.trend_name.split('|'), function (num) {
                return '\\b' + Functions.escapeRegExp(num) + '\\b';
            });
            where['company_dt.dt_name'] = new RegExp(keywords.join('|'), 'i');
        }
        pipeline.push({ $match: where });
        pipeline.push({ $addFields: { score: { $meta: 'textScore' } } });
        pipeline.push({ $sort: { company_published_date: -1, score: -1 } });
        pipeline.push({ $limit: limit });

        // console.log('where');
        // console.log(where);

        // console.log('pipeline');
        // console.log(pipeline);

        var result, reponse = [];
            result = await Company.aggregate(pipeline, (err, docs) => {
            if (err) {
                console.log(err)
            }
        });
        // console.log("result retured");
        if (!_.isEmpty(result)) {
            // flag to base64 encode 
            let btoaFb = new Buffer('fb').toString('base64');

            _.each(result, function (record) {
                var image = record['company_logo'];
                var imgBase64data = '';
                if (!_.isEmpty(image)) {
                    var img_file = process.env.BASE_PATH + '/public/upload/images/news/' + image;
                    if (fs.existsSync(img_file)) {
                        var buff = fs.readFileSync(img_file);
                        imgBase64data = buff.toString('base64');
                    }

                }
                var industry_tags = _.map(record['company_industry'], function (node) {
                    return node.industry_name;
                });
                var technology_tags = _.reject(_.map(record['company_dt'], function (node) {
                    return (node['dt_parent_id'] == 0) ? node['dt_name'] : null;
                }), _.isNull);

                // id to base64 encode 
                let btoaId = new Buffer(record['_id'].toString()).toString('base64');

                reponse.push({
                    'entity_id': record['_id'],
                    'entity_name': record['company_name'],
                    'entity_description': record['company_about'],
                    'entity_whats_unique': record['company_whats_unique'],
                    'entity_type': (record['company_is_startup']=='YES')?'Startup':'',
                    'entities_logo': imgBase64data,
                    'industry_tags': industry_tags,
                    'technology_tags': technology_tags,
                    'entity_public_url': process.env.SITE_URL + 'profile/company/' + record['company_public_id'] + '///////' + btoaFb,
                    'score': record['score']
                });
            });
            console.log('reponse returned');
            // console.log(reponse);
        }
        // insert API log
        const apiLog = new LogApiModel({
            request_date: new Date(),
            request_params: req.query,
            request_api:req.path,
            response_count: reponse.length,
        });
        await apiLog.save();
        return reponse;
    }

};