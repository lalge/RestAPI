//News.routes.js
const CompanyController = require('../controllers/company.controller');
var Joi = require('joi');
const Boom = require('boom');
module.exports = [
    {
        path: '/companies',
        method: 'GET',
        options: {
            description: 'Get Companies list',
            notes: 'Returns an array of Companies',
            tags: ['api'],
            validate: {
                query: {
                    search_keyword: Joi.string().required(),
                    industry_name: Joi.string(),
                    trend_name: Joi.string(),
                    page: Joi.number(),
                },
                failAction: (request, h, error) => {
                    return error.isJoi ? h.response(error.details[0]).takeover() : h.response(error).takeover();
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await CompanyController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
            
        }

    }
];