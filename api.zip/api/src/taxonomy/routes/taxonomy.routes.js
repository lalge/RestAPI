//Taxonomy.routes.js
const TaxonomyController = require('../controllers/taxonomy.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
const _ = require('underscore');
module.exports = [
    {
        path: '/taxonomy',
        method: 'GET',
        options: {
            description: 'Get Taxonomy list',
            notes: "Returns an array of Taxonomy.\n\n Parameters :\n\n `filter` is an object with customer's field as key and search keyword as its value `e.g { \"dtName\" : \"Energy Storage\"}` \n\n `field` will be array of taxonomy's fields in camelCase . If array is empty it will return all fields.",
            tags: ['api'],
            validate: {
                query: {
                    filter: Joi.object(
                        {
                            dtName: Joi.string(),
                            dtRoot: Joi.string().min(24).max(24).error(new Error('dtRoot must be a valid Mongo ID')),
                            dataAvailable: Joi.number().min(0).max(1),
                            availableForSubscription: Joi.number().min(0).max(1),
                            isLive: Joi.number().min(0).max(1),
                            dtParentName: Joi.string()
                        }
                    ),
                    productName:Joi.string().required(),
                    field: Joi.array(),
                    sort: Joi.object({
                        field: Joi.string(), order: Joi.number().min(-1).max(1),
                    }),
                    limit: Joi.number().default(10),
                    skip: Joi.number(),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await TaxonomyController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/taxonomy/{id}',
        method: 'GET',
        options: {
            description: 'Get Taxonomy By Id',
            notes: "Returns an Taxonomy Record",
            tags: ['api'],
            validate: {
                query: {
                    id:Joi.string().min(24).max(24).required().error(new Error('id must be a valid Mongo ID.')),
                    field: Joi.array()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await TaxonomyController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    }
];