//customer.controller.js
const LogApiModel = require('../../logs/models/log-api.model');
const Functions = require('../../../libs/function');
const remoteAppDbService = require('../../services/remoteAppDbService');
const Mongoose = require('mongoose');
const _ = require('underscore');
const fs = require('fs');
const sha1 = require('sha1');

module.exports = {
    find: async (req) => {
        var pipeline = [];
        var where = {};
        _.mapObject(req.query.filter, function (val, key) {
            let obj = {};
            if (key === "_id") {
                obj[key] = Mongoose.Types.ObjectId(val);
            } else {
                obj[Functions.decamelize(key)] = (_.isNumber(val)) ? val : new RegExp('^' + Functions.escapeRegExp(val) + '$', 'i');
            }
            if (typeof where['$and']==='undefined') {
                where['$and'] = [];
            }
            where['$and'].push(obj);
        });
        if (req.query.id) {
            if (typeof where['$and']==='undefined') {
                where['$and'] = [];
            }
            where['$and'].push({_id:Mongoose.Types.ObjectId(req.query.id)});
        }
       
        var columns = {};
        var isFilterExist = false;
        if (req.query.field) {
            _.each(req.query.field, function (column) {
                field = Functions.decamelize(column.field);
                columns[field] = 1
                if (typeof column.filter !== "undefined") {
                    isFilterExist = true;
                }
            });
        }

        if (!_.isEmpty(where)) {
            pipeline.push({ $match: where });
        }
        if (!_.isEmpty(columns)) {
            pipeline.push({ $project: columns });
        }
        //pipeline.push({ $addFields: { score: { $meta: 'textScore' } } });
        //pipeline.push({ $sort: { user_active: -1, score: -1 } });

        if(typeof req.query.sort !== 'undefined') {
            pipeline.push({ $sort:  req.query.sort });
        }
        if(typeof req.query.limit !== 'undefined') {
            pipeline.push({ $limit: req.query.limit });
        }
        if(typeof req.query.skip !== 'undefined') {
            pipeline.push({ $skip: req.query.skip  });
        }
        var result = [];
    //   fetch taxonomy from respective product DB
        if (!_.isEmpty(req.query.productName)) {
            result = await remoteAppDbService.getDataFromRemoteAppDb({
                remoteAppName: req.query.productName, // whatnext, industryinsider
                storageName: 'inx_taxonomy_dt',
                dbMethod: 'mongoAggregate', // mongoUpdate, mongoInsert
                pipeline: pipeline
            });
        }
        return result;
    }
};