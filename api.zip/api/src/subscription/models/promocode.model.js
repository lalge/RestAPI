//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;

const PromocodeSchema = new Schema(
    {
        promo_code: String,
        promo_code_start_date: Date,
        promo_code_end_date: Date
    }, { strict: false, versionKey: false });

module.exports = Mongoose.model('gnx_promo_code', PromocodeSchema, 'gnx_promo_code');