//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;
ObjectId = Schema.ObjectId;
const SubscriptionHistorySchema = new Schema(
    {
        user_id: ObjectId,
        subscription_id: ObjectId,
        subscription_name: String,
        subscription_type: String,
        subscription_purchased_date: Date,
        subscription_start_date: Date,
        subscription_end_date: Date,
        payment_details: {
            payment_date: Date
        },
        subscription_product_services: {
            product_id: ObjectId
        },
        subscription_package: {
            technology: Array,
            industry: Array,
            analyst_hours: Number,
            trends: Array
        },
        subscription_usage_limit:{
            start_date: Date,
            end_date: Date
        }
    }, { strict: false, versionKey: false });

module.exports = Mongoose.model('gnx_subscription_history', SubscriptionHistorySchema, 'gnx_subscription_history');