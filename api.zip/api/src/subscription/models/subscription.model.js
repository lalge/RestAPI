//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;

const SubscriptionSchema = new Schema(
    {
        subscription_name: String,
        subscription_product_services:{
            product_id : ObjectId
        },
    }, { strict: false, versionKey: false });

module.exports = Mongoose.model('gnx_subscription', SubscriptionSchema,'gnx_subscription');