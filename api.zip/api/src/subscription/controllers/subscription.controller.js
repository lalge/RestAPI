//subscription.controller.js
const Subscription = require('../models/subscription.model');
const Mongoose = require('mongoose');
const _ = require('underscore');
const Functions = require('../../../libs/function');

module.exports = {
    find: async (req) => {

        var where = {};
        if (typeof req.query.product_name != "undefined") {
            if (!_.isEmpty(req.query.product_name)) {
                where['$and'] = [];
                where['$and'].push({ 'subscription_product_services.product_name': new RegExp('^' + Functions.escapeRegExp(req.query.product_name) + '$', 'i') });
            }
        }
        if (typeof req.query.subscriptionId != "undefined") {
            if (!_.isEmpty(req.query.subscriptionId)) {
                if (_.isEmpty(where['$and'])) {
                    where['$and'] = [];
                }
                where['$and'].push({ '_id': Mongoose.Types.ObjectId(req.query.subscriptionId) });
            }
        }
        //console.log('WHERE', where);
        var result = [];
        result = await Subscription.find(where);
        //console.log('====RESULT====',result);
        return result;
    },
    create: async (req) => {
        var data = {
            _id: (typeof req.payload._id !== 'undefined') ? Mongoose.Types.ObjectId(req.payload._id) : Mongoose.Types.ObjectId(),
            subscription_name: req.payload.subscription_name,
            subscription_type: req.payload.subscription_type,
            subscription_pricing: req.payload.subscription_pricing,
            subscription_package: req.payload.subscription_package,
            subscription_product_services: req.payload.subscription_product_services,
            subscription_active: 'YES',
            subscription_usage_limit: req.payload.subscription_usage_limit,
            subscription_created_date: new Date(),
        };

        var SubscriptionModel = new Subscription(data);
        var result = await SubscriptionModel.save();

        return result;
    },
    update:async (req)=>{

        var data = {
            subscription_name: req.payload.subscription_name,
            subscription_type: req.payload.subscription_type,
            subscription_active: req.payload.subscription_active,
            subscription_pricing: req.payload.subscription_pricing,
            subscription_package: req.payload.subscription_package,
            subscription_product_services: req.payload.subscription_product_services,
            subscription_usage_limit: req.payload.subscription_usage_limit,
            subscription_last_modified_date: new Date()
        };
        var result = await Subscription.findByIdAndUpdate(Mongoose.Types.ObjectId(req.payload.subscriptionId), { $set: data }, { new: true });
        return result;
    }

};