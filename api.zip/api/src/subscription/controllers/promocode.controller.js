//promocode.controller.js
const Promocode = require('../models/promocode.model');
const Mongoose = require('mongoose');
const _ = require('underscore');
const Functions = require('../../../libs/function');

module.exports = {
    find: async (req) => {
        var result = [];
        result = await Promocode.find({ 'promo_code': req.query.promocode });
        //console.log('====RESULT====',result);
        return result;
    },

};