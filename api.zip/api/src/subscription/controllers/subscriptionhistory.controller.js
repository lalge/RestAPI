//subscription.controller.js
const SubscriptionHistoryModel = require('../models/subscriptionhistory.model');
const Mongoose = require('mongoose');
const _ = require('underscore');
const Functions = require('../../../libs/function');

module.exports = {
    find: async (req) => {

        var where = {};
        if (typeof req.query.historyId != "undefined") {
            if (!_.isEmpty(req.query.historyId)) {
                where._id = Mongoose.Types.ObjectId(req.query.historyId);
            }
        }
        if (typeof req.query.user_id != "undefined") {
            if (!_.isEmpty(req.query.user_id)) {
                where.user_id = Mongoose.Types.ObjectId(req.query.user_id);
            }
        }
        if (typeof req.query.subscriptionId != "undefined") {
            if (!_.isEmpty(req.query.subscriptionId)) {
                where.subscription_id = Mongoose.Types.ObjectId(req.query.subscriptionId);
            }
        }
        var result = [];
        result = await SubscriptionHistoryModel.find(where);
        return result;
    },
    //create history
    create: async (req) => {
        var history_data = {
            _id: (typeof req.payload._id !== 'undefined') ? Mongoose.Types.ObjectId(req.payload._id) : Mongoose.Types.ObjectId(),
            user_id: req.payload.user_id,
            subscription_id: req.payload.subscription_id,
            invoice_number: req.payload.invoice_number,
            subscription_name: req.payload.subscription_name,
            subscription_type: req.payload.subscription_type,
            subscription_purchased_date: req.payload.subscription_purchased_date,
            subscription_product_services: req.payload.subscription_product_services,
            subscription_package: req.payload.subscription_package,
            subscription_start_date: req.payload.subscription_start_date,
            subscription_end_date: req.payload.subscription_end_date,
            subscription_pricing: req.payload.subscription_pricing,
            payment_details: req.payload.payment_details,
            payment_mode: req.payload.payment_mode,
            subscription_status: (typeof req.payload.subscription_status !== 'undefined') ? req.payload.subscription_status : '',
            subscription_usage_limit:req.payload.subscription_usage_limit
        };
        var history = new SubscriptionHistoryModel(history_data);
        var result = await history.save();
        result = result.toObject();
        if (result.subscription_status == 'Active') {
            if (result.subscription_product_services.product_name == 'WhatNext') {
                let subscription_type = (result.subscription_type == 'TRIAL') ? 'Trial' : 'Register';
                var wn_dt_subscription = [];
                var wn_industry_subscription = [];

                for (var itemKey in result.subscription_package) {
                    if (itemKey == 'technology') {
                        // console.log(result.subscription_package[itemKey]);
                        _.each(result.subscription_package[itemKey], function (item) {
                            wn_dt_subscription.push({
                                subscription_history_id: result._id,
                                dt_name: item.dt_name,
                                dt_id: Mongoose.Types.ObjectId(item.dt_id),
                                subscription_type: subscription_type,
                                user_package: result.subscription_usage_limit,
                                subscription_start_date: result.subscription_start_date,
                                subscription_end_date: result.subscription_end_date
                            });
                        });
                    } else if (itemKey == 'industry') {
                        _.each(result.subscription_package[itemKey], function (item) {
                            wn_industry_subscription.push({
                                subscription_history_id: result._id,
                                industry_name: item.industry_name,
                                industry_id: Mongoose.Types.ObjectId(item.industry_id),
                                subscription_type: subscription_type,
                                user_package: result.subscription_usage_limit,
                                subscription_start_date: result.subscription_start_date,
                                subscription_end_date: result.subscription_end_date
                            });
                        });
                    }

                }



                //create same customer in WhatNext
                var wn_customer_data = {};
                wn_customer_data.user_subscribe_dt = [];
                wn_customer_data.user_subscribe_industry = [];
                if (!_.isEmpty(wn_dt_subscription)) {
                    wn_customer_data.user_subscribe_dt = wn_dt_subscription;
                }
                if (!_.isEmpty(wn_industry_subscription)) {
                    wn_customer_data.user_subscribe_industry = wn_industry_subscription;
                }
                if (!_.isEmpty(wn_dt_subscription) || !_.isEmpty(wn_industry_subscription)) {
                    await Functions.updateWhatNextUser({
                        subscription_history_id: result._id, userId: result.user_id, dataToUpdate: wn_customer_data
                    });
                }

            }
        }

        return result;
    },
    update: async (req) => {

        var history_data = {};
        if (!_.isEmpty(req.payload.user_id)) {
            history_data.user_id = req.payload.user_id;
        }
        if (!_.isEmpty(req.payload.subscription_id)) {
            history_data.subscription_id = req.payload.subscription_id;
        }
        if (!_.isEmpty(req.payload.invoice_number)) {
            history_data.invoice_number = req.payload.invoice_number;
        }
        if (!_.isEmpty(req.payload.subscription_name)) {
            history_data.subscription_name = req.payload.subscription_name;
        }
        if (req.payload.subscription_type) {
            history_data.subscription_type = req.payload.subscription_type;
        }
        if (req.payload.subscription_purchased_date) {
            history_data.subscription_purchased_date = req.payload.subscription_purchased_date;
        }
        if (req.payload.subscription_product_services) {
            history_data.subscription_product_services = req.payload.subscription_product_services;
        }
        if (req.payload.subscription_package) {
            history_data.subscription_package = req.payload.subscription_package;
        }
        if (req.payload.subscription_start_date) {
            history_data.subscription_start_date = req.payload.subscription_start_date;
        }
        if (req.payload.subscription_end_date) {
            history_data.subscription_end_date = req.payload.subscription_end_date;
        }
        if (req.payload.subscription_pricing) {
            history_data.subscription_pricing = req.payload.subscription_pricing;
        }
        if (req.payload.payment_details) {
            history_data.payment_details = req.payload.payment_details;
        }
        if (req.payload.payment_mode) {
            history_data.payment_mode = req.payload.payment_mode;
        }
        if (req.payload.subscription_status) {
            history_data.subscription_status = req.payload.subscription_status;
        }
        if (req.payload.subscription_usage_limit) {
            history_data.subscription_usage_limit = req.payload.subscription_usage_limit;
        }
        
        // console.log('history_data',history_data);
        var result = await SubscriptionHistoryModel.findByIdAndUpdate(Mongoose.Types.ObjectId(req.payload.historyId), { $set: history_data }, { new: true });
        result = result.toObject();

        if (result.subscription_status == 'Active') {
            if (result.subscription_product_services.product_name == 'WhatNext') {
                let subscription_type = (result.subscription_type == 'TRIAL') ? 'Trial' : 'Register';
                var wn_dt_subscription = [];
                var wn_industry_subscription = [];

                for (var itemKey in result.subscription_package) {

                    if (itemKey == 'technology') {
                        // console.log(result.subscription_package[itemKey]);
                        _.each(result.subscription_package[itemKey], function (item) {
                            wn_dt_subscription.push({
                                subscription_history_id: result._id,
                                dt_name: item.dt_name,
                                dt_id: Mongoose.Types.ObjectId(item.dt_id),
                                subscription_type: subscription_type,
                                user_package: result.subscription_usage_limit,
                                subscription_start_date: result.subscription_start_date,
                                subscription_end_date: result.subscription_end_date
                            });
                        });
                    } else if (itemKey == 'industry') {
                        _.each(result.subscription_package[itemKey], function (item) {
                            wn_industry_subscription.push({
                                subscription_history_id: result._id,
                                industry_name: item.industry_name,
                                industry_id:  Mongoose.Types.ObjectId(item.industry_id),
                                subscription_type: subscription_type,
                                user_package: result.subscription_usage_limit,
                                subscription_start_date: result.subscription_start_date,
                                subscription_end_date: result.subscription_end_date
                            });
                        });
                    }

                }
                //create same customer in WhatNext
                var wn_customer_data = {};
                wn_customer_data.user_subscribe_dt = [];
                wn_customer_data.user_subscribe_industry = [];
                if (!_.isEmpty(wn_dt_subscription)) {
                    wn_customer_data.user_subscribe_dt = wn_dt_subscription;
                }
                if (!_.isEmpty(wn_industry_subscription)) {
                    wn_customer_data.user_subscribe_industry = wn_industry_subscription;
                }
                if (!_.isEmpty(wn_dt_subscription) || !_.isEmpty(wn_industry_subscription)) {
                    await Functions.updateWhatNextUser({
                        subscription_history_id: result._id, userId: result.user_id, dataToUpdate: wn_customer_data
                    });
                }
               
            }
        }
        return result;
    },

};