//Subscription.routes.js
const SubscriptionController = require('../controllers/subscription.controller');
const SubscriptionHistoryController = require('../controllers/subscriptionhistory.controller');
const ProductServicesController = require('../../default/controllers/productservices.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
module.exports = [
    {
        path: '/subscriptions',
        method: 'GET',
        options: {
            description: 'Get Products Subscriptions list',
            notes: 'Returns an array of Subscription. \n\n Parameters :\n\n `product_name`(optional) is Product name (WhatNext, IndustryInsider)\n\n `subscription_id`(optional) is an object id of Subscription.\n\n If no parameter is send it will return all Subscriptions.',
            tags: ['api'],
            validate: {
                query: {
                    product_name: Joi.string(),
                    subscriptionId: Joi.string().min(24).max(24).error(new Error('Please provide valid Subscription Id')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions/{subscriptionId}',
        method: 'GET',
        options: {
            description: 'Get Products Subscriptions list',
            notes: 'Returns an array of Subscription. \n\n Parameters :\n\n `product_name`(optional) is Product name (WhatNext, IndustryInsider)\n\n `subscription_id`(optional) is an object id of Subscription.\n\n If no parameter is send it will return all Subscriptions.',
            tags: ['api'],
            validate: {
                query: {
                    subscriptionId: Joi.string().min(24).max(24).required().error(new Error('subscriptionId is required and it should be a valid Mongo ID.')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions',
        method: 'POST',
        options: {
            description: 'Create  Subscriptions',
            notes: 'Returns Subscription ',
            tags: ['api'],
            validate: {
                payload: {
                    subscription_name: Joi.string().required(),
                    subscription_type: Joi.string().valid('BASE', 'TRIAL', 'CUSTOM').required(),
                    subscription_pricing: Joi.array().items(Joi.object({
                        validity_in_days: Joi.number(),
                        price_currency: Joi.string(),
                        actual_price_value: Joi.number(),
                        special_price: Joi.number(),
                        special_price_validity_start_date: Joi.date().allow(''),
                        special_price_validity_end_date: Joi.date().allow('')
                    })).required(),
                    subscription_package: Joi.object({
                        technology: Joi.number().description('No. of Technologies'),
                        industry: Joi.number().description('No. of Industries'),
                        analyst_hours: Joi.number().description('No. of Analyst hours'),
                        trends: Joi.number().description('No. of Trends'),
                    }).required(),
                    subscription_product_services: Joi.object().keys({
                        product_id: Joi.string().min(24).max(24).required().error(new Error('product_id must be a valid Mongo ID.')),
                        product_name: Joi.string().required(),
                    }).required(),
                    subscription_usage_limit: Joi.object().keys({
                        max_patent_per_listing: Joi.number(),
                        max_companies_per_listing: Joi.number(),
                        max_products_per_listing: Joi.number(),
                    }),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionController.create(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions/{subscriptionId}',
        method: 'PUT',
        options: {
            description: 'Update  Subscriptions',
            notes: 'Returns updated Subscription.',
            tags: ['api'],
            validate: {
                payload: {
                    subscriptionId: Joi.string().min(24).max(24).required().error(new Error('Please provide valid Subscription Id')),
                    subscription_name: Joi.string().required(),
                    subscription_type: Joi.string().valid('BASE', 'TRIAL', 'CUSTOM').required(),
                    subscription_active: Joi.string().valid('YES', 'NO').required(),
                    subscription_pricing: Joi.array().items(Joi.object({
                        validity_in_days: Joi.number(),
                        price_currency: Joi.string(),
                        actual_price_value: Joi.number(),
                        special_price: Joi.number(),
                        special_price_validity_start_date: Joi.date().allow(''),
                        special_price_validity_end_date: Joi.date().allow('')
                    })).required(),
                    subscription_package: Joi.object({
                        technology: Joi.number().description('No. of Technologies'),
                        industry: Joi.number().description('No. of Industries'),
                        analyst_hours: Joi.number().description('No. of Analyst hours'),
                        trends: Joi.number().description('No. of Trends'),
                    }).required(),
                    subscription_product_services: Joi.object().keys({
                        product_id: Joi.string().min(24).max(24).required().error(new Error('product_id must be a valid Mongo ID.')),
                        product_name: Joi.string().required(),
                    }).required(),
                    subscription_usage_limit: Joi.object().keys({
                        max_patent_per_listing_register: Joi.number(),
                        max_companies_per_listing_register: Joi.number(),
                        max_products_per_listing_register: Joi.number(),
                        // show_listing_total_count: Joi.string().valid('YES', 'NO')
                    }).required()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionController.update(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions/history/{historyId}',
        method: 'GET',
        options: {
            description: 'Get Subscriptions History By Id',
            notes: 'Returns an array of Subscription history.',
            tags: ['api'],
            validate: {
                query: {
                    historyId: Joi.string().min(24).max(24).required().error(new Error('historyId is required and it should be a valid Mongo ID.')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionHistoryController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions/history',
        method: 'GET',
        options: {
            description: 'Get Subscriptions History',
            notes: 'Returns an array of Subscription history.',
            tags: ['api'],
            validate: {
                query: {
                    
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await SubscriptionHistoryController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/subscriptions/history/{historyId}',
        method: 'PUT',
        options: {
            description: 'Upate Subscription History',
            notes: "Returns keyword `success` on succesfully updation.",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    historyId: Joi.string().min(24).max(24).required().error(new Error('_id must be a valid Mongo ID.')),
                    user_id: Joi.string().min(24).max(24).error(new Error('user_id must be a valid Mongo ID.')),
                    subscription_id: Joi.string().min(24).max(24).error(new Error('subscription_id must be a valid Mongo ID.')),
                    invoice_number: Joi.string(),
                    subscription_name: Joi.string(),
                    subscription_type: Joi.string(),
                    subscription_purchased_date: Joi.date(),
                    subscription_start_date: Joi.date(),
                    subscription_end_date: Joi.date(),
                    subscription_product_services: Joi.object().keys({
                        product_id: Joi.string().min(24).max(24).error(new Error('product_id must be a valid Mongo ID.')),
                        product_name: Joi.string(),
                    }),
                    subscription_package: Joi.object(),
                    subscription_pricing: Joi.object(),
                    payment_details: Joi.object(),
                    payment_mode: Joi.string()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    // create subscription history
                    const historyId = await SubscriptionHistoryController.update(req);
                    if (typeof historyId._id !== "undefined") {
                        //  return success message
                        return h.response({ 'response': 'success',historyId: historyId._id});
                    } else {
                        return Boom.badRequest('Error occured while creating subscription history.');
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
];