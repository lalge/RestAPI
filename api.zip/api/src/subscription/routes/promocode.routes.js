//promocode.routes.js
const PromocodeController = require('../controllers/promocode.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
module.exports = [
    {
        path: '/promocode',
        method: 'GET',
        options: {
            description: 'Get Promocode',
            notes: 'Returns an array of Promocode.\n\n Result Array Structure:\n\n\t[{\n\n\t"promo_code" : "OFF20",\n\n\t"promo_code_value" : "20",\n\n\t"promo_code_discount_type" : "percentage",\n\n\t"promo_code_start_date" : "2019-12-12T07:19:24.436+0000",\n\n\t"promo_code_end_date" : "2019-12-12T07:19:24.436+0000",\n\n\t"promo_code_is_active" : "YES"}] \n\n Parameters :\n\n `promocode` is a promocode value.\n\n Promocode will be case-sensitive.',
            tags: ['api'],
            validate: {
                query: {
                    promocode: Joi.string().required().error(new Error('Please provide valid Promocode.'))
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await PromocodeController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }

    }
];