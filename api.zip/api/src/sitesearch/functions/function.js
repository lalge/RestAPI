var SolrNode = require('solr-node');
const _ = require('underscore');
module.exports = {

  queryNews(req) {
    var searchQueryNews = '';
    searchQueryNews += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryNews += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    //searchQueryNews += "((title:" + encodeURI(req.query['searchKeyword']) + "))";


    searchQueryNews += "((title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(content:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryNews += "&rows=" + req.query['limit'];
    return searchQueryNews;
  },


  queryEarlySignal(req) {
    // req.query['searchKeyword'] = "vehicle";
    var searchQueryEarlySignal = '';
    searchQueryEarlySignal += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryEarlySignal += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryEarlySignal += "((title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(content:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryEarlySignal += "&rows=" + req.query['limit'];
    return searchQueryEarlySignal;
  },

  queryVideos(req) {
    var searchQueryVideos = '';
    searchQueryVideos += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryVideos += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryVideos += "((title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(content:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryVideos += "&rows=" + req.query['limit'];
    return searchQueryVideos;
  },

  queryTechAdopdation(req) {
    var searchQueryTechAdopdation = '';
    searchQueryTechAdopdation += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryTechAdopdation += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryTechAdopdation += "((title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(content:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryTechAdopdation += "&rows=" + req.query['limit'];
    return searchQueryTechAdopdation;
  },

  queryDocument(req) {
    var searchQueryDocument = '';
    searchQueryDocument += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryDocument += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryDocument += "((title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(content:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(_text_:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryDocument += "&rows=" + req.query['limit'];
    return searchQueryDocument;
  },

  queryCompany(req) {
    var searchQueryCompany = '';
    searchQueryCompany += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryCompany += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryCompany += "((name:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(description:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(whats_unique:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryCompany += "&rows=" + req.query['limit'];
    // var searchQueryCompany = 'q=_id:5d6585aa0e5bf37f221dba8f';

    return searchQueryCompany;
  },

  queryProduct(req) {
    var searchQueryProduct = '';
    searchQueryProduct += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryProduct += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }
    searchQueryProduct += "((name:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(description:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(whats_unique:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(company_name:" + encodeURI(req.query['searchKeyword']) + "))";
    searchQueryProduct += "&rows=" + req.query['limit'];
    // var searchQueryCompany = 'q=_id:5d6585aa0e5bf37f221dba8f';

    return searchQueryProduct;
  },

  queryPatent(req) {
    var searchQueryPatent = '';
    searchQueryPatent += "q=(platform_type:" + req.query['productPlatform'] + ")%20AND%20";
    if (req.query['technology'] !== 'undefined') {
      if (_.isArray(req.query['technology'])) {
        searchQueryPatent += "(technology_id:" + req.query['technology'][0] + ")%20AND%20";
      }
    }

    searchQueryPatent += "((patent_number:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_title:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_description:" + encodeURI(req.query['searchKeyword']) + ")";
    searchQueryPatent += "%20OR%20(patent_abstract:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_kind_code:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_country_name:" + encodeURI(req.query['searchKeyword']) + ")";
    //searchQueryPatent += "%20OR%20(patent_ip_rights_expiry_year:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_remaining_year:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_invention_maturity_level:" + encodeURI(req.query['searchKeyword']) + ")";
    //searchQueryPatent += "%20OR%20(patent_invention_type:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_licensing_availability:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_criticality_to_technology:" + encodeURI(req.query['searchKeyword']) + ")";
    searchQueryPatent += "%20OR%20(patent_assignee:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_ipc_classes:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(patent_cpc_classes:" + encodeURI(req.query['searchKeyword']) + ")";
    searchQueryPatent += "%20OR%20(publication_year:" + encodeURI(req.query['searchKeyword']) + ")%20OR%20(taxonomy_tags:" + encodeURI(req.query['searchKeyword']) + ")";

    searchQueryPatent += ")";




    searchQueryPatent += "&rows=" + req.query['limit'];
    // var searchQueryCompany = 'q=_id:5d6585aa0e5bf37f221dba8f';

    return searchQueryPatent;
  },



  async searchInNews(str, news_cb) {
    var SolrclientNews = new SolrNode({
      host: process.env.SOLR_DOMAIN,
      port: process.env.SOLR_PORT,
      core: process.env.SOLR_CORE_NEWS,
      protocol: process.env.SOLR_PROTOCOL
    });

    console.log("in searchInNews function");
    const resultNews = await SolrclientNews.search(str);
    console.log("after searchInNews results");
    //console.log(resultNews);
    news_cb(resultNews);
  },

  async searchInCompany(str, company_cb) {

    var SolrclientCompany = new SolrNode({
      host: process.env.SOLR_DOMAIN,
      port: process.env.SOLR_PORT,
      core: process.env.SOLR_CORE_COMPANY,
      protocol: process.env.SOLR_PROTOCOL
    });
    // console.log("searchInCompany");
    const resultCompany = await SolrclientCompany.search(str);
    company_cb(resultCompany);
  },


  // async searchInNews(str) {
  //   var SolrclientNews = new SolrNode({
  //     host: process.env.SOLR_DOMAIN,
  //     port: process.env.SOLR_PORT,
  //     core: process.env.SOLR_CORE_NEWS,
  //     protocol: process.env.SOLR_PROTOCOL
  //   });
  //   console.log("33333333333");
  //   console.log("searchInNews");
  //   console.log("news str");
  //   console.log(str);
  //   const resultNews = await SolrclientNews.search(str);
  //   console.log("after searchInNews");
  //   console.log("44444444444");
  //   console.log(resultNews);
  //   return resultNews;

  // },

  // async searchInCompany(str) {

  //   var SolrclientCompany = new SolrNode({
  //     host: process.env.SOLR_DOMAIN,
  //     port: process.env.SOLR_PORT,
  //     core: process.env.SOLR_CORE_COMPANY,
  //     protocol: process.env.SOLR_PROTOCOL
  //   });
  //   // console.log("searchInCompany");
  //   const resultCompany = await SolrclientCompany.search(str);
  //   //console.log("after searchInCompany");
  //   //console.log(resultCompany);
  //   return resultCompany;

  // }

};