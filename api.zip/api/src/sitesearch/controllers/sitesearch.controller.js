//sitesearch.controller.js
'use strict';
const Functions = require('../functions/function.js');
const _ = require('underscore');
var SolrNode = require('solr-node');
var async = require("async");
require('log4js').getLogger('solr-node').level = 'DEBUG';
// Create client NEWS



// Create client Company








module.exports = {
  searchProductContent: async (req) => {

    //   q=(platform_type:WhatNext)%20AND%20(technology_id:' . $dt_id . ')%20AND%20((title:' . urlencode($out) . ')%20OR%20(content:' . urlencode($out) . ')%20OR%20(taxonomy_tags:' . urlencode($out) . '))&rows=10000000';   
    var searchQueryNews = '';
    searchQueryNews = Functions.queryNews(req);

    // Early Signal
    var searchQueryEarlySignal = '';
    searchQueryEarlySignal = Functions.queryEarlySignal(req);

    // Videos
    var searchQueryVideos = '';
    searchQueryVideos = Functions.queryVideos(req);

    // TechAdopdation
    var searchQueryTechAdopdation = '';
    searchQueryTechAdopdation = Functions.queryTechAdopdation(req);

    // Document
    var searchQueryDocument = '';
    searchQueryDocument = Functions.queryDocument(req);

    //   Companies
    var searchQueryCompany = '';
    searchQueryCompany = Functions.queryCompany(req);

    //   Product
    var searchQueryProduct = '';
    searchQueryProduct = Functions.queryProduct(req);
    //console.log(searchQueryCompany);

    //   Patent
    var searchQueryPatent = '';
    searchQueryPatent = Functions.queryPatent(req);

    //   Video
    var searchQueryVideo = '';
    searchQueryVideo = Functions.queryVideos(req);


    try {

      const resultNews = async function (str) {

        var SolrclientNews = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_NEWS,
          protocol: process.env.SOLR_PROTOCOL
        });
        const resultNews = await SolrclientNews.search(str);
        return resultNews;
      };

      const resultEarlySignal = async function (str) {

        var SolrclientEarlySignal = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_EARLYSIGNAL,
          protocol: process.env.SOLR_PROTOCOL
        });
        const resultEarlySignal = await SolrclientEarlySignal.search(str);
        return resultEarlySignal;
      };
      const resultCompany = async function (str) {
        var SolrclientCompany = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_COMPANY,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultCompany = await SolrclientCompany.search(str);
        return resultCompany;
      };

      const resultProduct = async function (str) {
        var SolrclientProduct = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_PRODUCT,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultProduct = await SolrclientProduct.search(str);
        return resultProduct;
      };

      const resultDocument = async function (str) {
        var SolrclientDocument = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_DOCUMENT,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultDocument = await SolrclientDocument.search(str);
        return resultDocument;
      };

      const resultPatent = async function (str) {
        var SolrclientPatent = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_PATENT,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultPatent = await SolrclientPatent.search(str);
        return resultPatent;
      };

      const resultVideo = async function (str) {
        var SolrclientVideo = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_VIDEO,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultVideo = await SolrclientVideo.search(str);
        return resultVideo;
      };
      const resultTechAdopdation = async function (str) {
        var SolrclientTechAdopdation = new SolrNode({
          host: process.env.SOLR_DOMAIN,
          port: process.env.SOLR_PORT,
          core: process.env.SOLR_CORE_TECH_ADOPTION,
          protocol: process.env.SOLR_PROTOCOL
        });

        const resultTechAdopdation = await SolrclientTechAdopdation.search(str);
        return resultTechAdopdation;
      };



      const result = [];
      await Promise.all([resultNews(searchQueryNews), resultCompany(searchQueryCompany), resultEarlySignal(searchQueryEarlySignal), resultProduct(searchQueryProduct), resultDocument(searchQueryDocument), resultPatent(searchQueryPatent), resultVideo(searchQueryVideo), resultTechAdopdation(searchQueryTechAdopdation)])
        .then(([news, company, earlySignal, product, document, patent, video, techAdoption]) => {

          // await Promise.all([resultNews(searchQueryNews)])
          //   .then(([news]) => {
          _.each(news.response.docs, function (record) {
            record.content_type = 'news';
            result.push(record);
          });
          _.each(company.response.docs, function (record) {
            record.content_type = 'company';
            result.push(record);
          });
          // console.log("early signal");
          //console.log(earlySignal.response.docs);
          _.each(earlySignal.response.docs, function (record) {
            record.content_type = 'earlysignal';
            result.push(record);
          });
          _.each(product.response.docs, function (record) {
            record.content_type = 'product';
            result.push(record);
          });

          _.each(document.response.docs, function (record) {
            record.content_type = 'document';
            result.push(record);
          });

          _.each(patent.response.docs, function (record) {
            record.content_type = 'patent';
            result.push(record);
          });
          _.each(video.response.docs, function (record) {
            record.content_type = 'video';
            result.push(record);
          });
          _.each(techAdoption.response.docs, function (record) {
            record.content_type = 'techadoption';
            result.push(record);
          });





        })
        .catch(err => console.log(err));

      return {
        totalRecordFound: (result) ? result.length : 0,
        result: result
      };
    } catch (e) {
      console.error(e);
    }
  },


};