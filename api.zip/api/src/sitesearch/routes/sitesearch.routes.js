//News.routes.js
'use strict';
const SiteSearchController = require('../controllers/sitesearch.controller');
const _ = require('underscore');
var Joi = require('joi');
const Boom = require('boom');
module.exports = [
    {
        path: '/sitesearch',
        method: 'GET',
        options: {
            description: 'Search in Product contents (News, Companies, Products etc..) ',
            notes: 'Returns an array of consolidated search results',
            tags: ['api'],
            validate: {
                query: {
                    productPlatform: Joi.string().required(),
                    search_in_content: Joi.string().required(),
                    technology: Joi.array(),
                    industry: Joi.array(),
                    searchKeyword: Joi.string().required(),
                    limit: Joi.number(),
                    offset: Joi.number(),
                },
                failAction: (request, h, error) => {
                    return error.isJoi ? h.response(error.details[0]).takeover() : h.response(error).takeover();
                }
            },

            handler: async (req, h) => {
                try {
                    console.log(req.query);
                    const result = await SiteSearchController.searchProductContent(req);
                    // console.log("RESULT",result);
                    // let totalRecordFound = 0;
                    // const searchResult = [];
                    // Promise.all(result)
                    // .then((allResult)=>{
                    //     console.log("ALLRESULT",allResult);
                    // })
                    // .catch((e)=>console.log(e));

                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
        },


    }
];