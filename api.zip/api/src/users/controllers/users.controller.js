//users.controller.js
const UsersModel = require('../models/users.model');
const LogApiModel = require('../../logs/models/log-api.model');
const Functions = require('../../../libs/function');
const remoteAppDbService = require('../../services/remoteAppDbService');
const Mongoose = require('mongoose');
const _ = require('underscore');
const fs = require('fs');
const sha1 = require('sha1');

module.exports = {
    find: async (req) => {
        var pipeline = [];
        var where = {};

        _.mapObject(req.query.filter, function (val, key) {
            let obj = {};
            if (key === "_id") {
                obj[key] = Mongoose.Types.ObjectId(val);
            } else {
                obj[Functions.decamelize(key)] = (_.isNumber(val)) ? val : new RegExp('^' + Functions.escapeRegExp(val) + '$', 'i');
            }
            if (typeof where['$and'] === 'undefined') {
                where['$and'] = [];
            }
            where['$and'].push(obj);
        });
        if (req.query.userId) {
            if (typeof where['$and']==='undefined') {
                where['$and'] = [];
            }
            where['$and'].push({_id:Mongoose.Types.ObjectId(req.query.userId)});
        }
        var columns = {};
        var isFilterExist = false;
        if (req.query.field) {
            _.each(req.query.field, function (column) {
                field = Functions.decamelize(column.field);
                columns[field] = 1
                if (typeof column.filter !== "undefined") {
                    isFilterExist = true;
                }
            });
        }

        if (!_.isEmpty(where)) {
            pipeline.push({ $match: where });
        }
        if (!_.isEmpty(columns)) {
            pipeline.push({ $project: columns });
        }
        if (typeof req.query.sort !== 'undefined') {
            pipeline.push({ $sort: req.query.sort });
        }
        if (typeof req.query.limit !== 'undefined') {
            pipeline.push({ $limit: req.query.limit });
        }
        if (typeof req.query.skip !== 'undefined') {
            pipeline.push({ $skip: req.query.skip });
        }

        var result = [];
        result = await UsersModel.aggregate(pipeline, (err, docs) => {
            if (err) {
                console.log(err)
            }
        });
        // console.log("result retured");
        if (!_.isEmpty(result)) {
            _.each(result, function (record) {
                delete record.user_password;
                var image = record['user_profile_picture'];
                var imgBase64data = '';
                if (!_.isEmpty(image)) {
                    var img_file = process.env.BASE_PATH + '/public/assets-cms/users/' + image;
                    if (fs.existsSync(img_file)) {
                        var buff = fs.readFileSync(img_file);
                        imgBase64data = buff.toString('base64');
                        record.user_profile_picture = imgBase64data;
                    }
                }
                /*if(isFilterExist){
                    var filter_data = [];
                    _.each(req.query.field, function (column) {
                        if(typeof column.filter !=="undefined"){
                            var field_name = Functions.decamelize(column.field);
                            for(var k in column.filter){
                                k = Functions.decamelize(k);
                                var field_arr = k.split(".");
                                for (var i = 0; i < field_arr.length; i++) {
                                    if(typeof record[field_name][field_arr[0]] !=="undefined"){
                                        
                                        for (var i = 0; i < field_arr.length; i++) {

                                        }
                                    }
                                }
                                
                            }
                        }
                    });
                }*/



            });
            console.log('result returned');
            // console.log(reponse);
        }
        return result;
    },
    //create user
    create: async (req) => {
        var user_data = {
            user_fname: req.payload.user_fname,
            user_lname: req.payload.user_lname,
            user_email: req.payload.user_email,
            user_password: sha1(sha1(req.payload.user_password) + '::' + process.env.SALT),
            user_login_id: (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '',
            user_active: req.payload.user_active,
            user_profile_picture: (typeof req.payload.user_profile_picture !== 'undefined') ? req.payload.user_profile_picture : '',
            user_technical_competencies: (typeof req.payload.user_technical_competencies !== 'undefined') ? req.payload.user_technical_competencies : [],
            user_futurebridge_relevancy: (typeof req.payload.user_futurebridge_relevancy !== 'undefined') ? req.payload.user_futurebridge_relevancy : [],
            user_about: (typeof req.payload.user_about !== 'undefined') ? req.payload.user_about : '',
            user_social_links: (typeof req.payload.user_social_links !== 'undefined') ? req.payload.user_social_links : {},
            user_work_experience: (typeof req.payload.user_work_experience !== 'undefined') ? req.payload.user_work_experience : [],
            user_educational_qualification: (typeof req.payload.user_educational_qualification !== 'undefined') ? req.payload.user_educational_qualification : [],
            user_vendor_details: (typeof req.payload.user_vendor_details !== 'undefined') ? req.payload.user_vendor_details : [],
            user_personal_address: (typeof req.payload.user_personal_address !== 'undefined') ? req.payload.user_personal_address : [],
            user_office_address: (typeof req.payload.user_office_address !== 'undefined') ? req.payload.user_office_address : [],
            user_type: (typeof req.payload.user_type !== 'undefined') ? req.payload.user_type : '',
            user_access: req.payload.user_access,
            user_registration_date: new Date(),
            user_last_modified_date: new Date()
        };
        var users = new UsersModel(user_data);
        var result = await users.save();
        result = JSON.parse(JSON.stringify(result));
        if (!_.isEmpty(result._id)) {
            var wn_cms_userdata = { '_id': Mongoose.Types.ObjectId(result._id), ...user_data };
            await remoteAppDbService.setDataInRemoteAppDb({
                remoteAppName: 'whatnext_cms', // whatnext, industryinsider, whatnext_cms
                storageName: 'inx_user',
                dbMethod: 'mongoInsert', // mongoUpdate, mongoInsert
                where: {},
                data: wn_cms_userdata
            });

            return result;

        } else {
            return [];
        }
    },
    update: async (req) => {
        var user_data = {
            user_fname: req.payload.user_fname,
            user_lname: req.payload.user_lname,
            user_email: req.payload.user_email,
            user_access: req.payload.user_access,
            user_last_modified_date: new Date()
        };
        if (typeof req.payload.user_login_id !== 'undefined') {
            if (!_.isEmpty(req.payload.user_login_id)) {
                user_data.user_login_id = req.payload.user_login_id;
            }
        }
        if (typeof req.payload.user_personal_address !== 'undefined') {
            if (!_.isEmpty(req.payload.user_personal_address)) {
                user_data.user_personal_address = req.payload.user_personal_address;
            }
        }
        if (typeof req.payload.user_office_address !== 'undefined') {
            if (!_.isEmpty(req.payload.user_office_address)) {
                user_data.user_office_address = req.payload.user_office_address;
            }
        }
        if (typeof req.payload.user_profile_picture !== 'undefined') {
            if (!_.isEmpty(req.payload.user_profile_picture)) {
                user_data.user_profile_picture = req.payload.user_profile_picture;
                
            }
        }
        if (typeof req.payload.user_social_links !== 'undefined') {
            if (!_.isEmpty(req.payload.user_social_links)) {
                user_data.user_social_links = req.payload.user_social_links;
            }
        }

        if (typeof req.payload.user_password !== "undefined") {
            if (!_.isEmpty(req.payload.user_password)) {
                user_data.user_password = sha1(sha1(req.payload.user_password) + '::' + process.env.SALT);
            }
        }
        if (typeof req.payload.user_active !== "undefined") {
            if (!_.isEmpty(req.payload.user_active)) {
                user_data.user_active = req.payload.user_active;
            }
        }

        if (typeof req.payload.user_technical_competencies !== 'undefined') {
            if (!_.isEmpty(req.payload.user_technical_competencies)) {
                user_data.user_technical_competencies = req.payload.user_technical_competencies;
            }
        }

        if (typeof req.payload.user_futurebridge_relevancy !== 'undefined') {
            if (!_.isEmpty(req.payload.user_futurebridge_relevancy)) {
                user_data.user_futurebridge_relevancy = req.payload.user_futurebridge_relevancy;
            }
        }

        if (typeof req.payload.user_about !== 'undefined') {
            if (!_.isEmpty(req.payload.user_about)) {
                user_data.user_about = req.payload.user_about;
            }
        }

        if (typeof req.payload.user_work_experience !== 'undefined') {
            if (!_.isEmpty(req.payload.user_work_experience)) {
                user_data.user_work_experience = req.payload.user_work_experience;
            }
        }

        if (typeof req.payload.user_educational_qualification !== 'undefined') {
            if (!_.isEmpty(req.payload.user_educational_qualification)) {
                user_data.user_educational_qualification = req.payload.user_educational_qualification;
            }
        }

        if (typeof req.payload.user_vendor_details !== 'undefined') {
            if (!_.isEmpty(req.payload.user_vendor_details)) {
                user_data.user_vendor_details = req.payload.user_vendor_details;
            }
        }

        if (typeof req.payload.user_type !== 'undefined') {
            if (!_.isEmpty(req.payload.user_type)) {
                user_data.user_type = req.payload.user_type;
            }
        }

        var result = await UsersModel.findByIdAndUpdate(Mongoose.Types.ObjectId(req.payload.userId), { $set: user_data }, { new: true });
        await remoteAppDbService.setDataInRemoteAppDb({
            remoteAppName: 'whatnext_cms',
            storageName: 'inx_user',
            dbMethod: 'mongoUpdate',
            where: { _id: Mongoose.Types.ObjectId(req.payload.userId) },
            data: { $set: user_data }
        });

        //console.log(result);
        return result;

    },
    /**
     * check if user already exists in our DB.
     * 
     * @param Email_id
     * @param Login_id
     * @param User Mongo Id (for PUT request in POST request it will be empty)
     */
    checkIsUserExist: async (email_id, login_id, user_id) => {
        //create dynamic query to check of user's email or login id exists
        var query = {};
        query['$and'] = [];
        if (!_.isEmpty(login_id)) {
            query['$or'] = [];
            query['$or'].push({ 'user_email': email_id }, { 'user_login_id': login_id });
            delete query['$and'];
        } else {
            query['$and'].push({ 'user_email': email_id });
        }
        if (!_.isEmpty(user_id)) {
            if (_.isEmpty(query['$and'])) {
                query['$and'] = [];
            }
            query['$and'].push({ '_id': { '$ne': Mongoose.Types.ObjectId(user_id) } });
        }
        var user = await UsersModel.findOne(query);
        if (_.isEmpty(user)) {
            return [];
        } else {
            return user;
        }
    },

};