//Users.routes.js
const UsersController = require('../controllers/users.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
const _ = require('underscore');
module.exports = [ 
    {
        path: '/users',
        method: 'POST',
        options: {
            description: 'Create GenX CMS Users',
            notes: "Returns keyword `success` on succesfully cms user creation.\n\n Returns keyword `email_exists` if email id already exists.\n\n Returns keyword `loginid_exists` if login id already exists.",
            tags: ['api'],
            // plugins: {
            //     'hapi-swagger': {
            //         payloadType: 'form'
            //     }
            // },
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    user_fname: Joi.string().min(1).max(50).required(),
                    user_lname: Joi.string().min(1).max(50).required(),
                    user_email: Joi.string().email().required(),
                    user_password: Joi.string().required(),
                    user_access: Joi.array().items(Joi.object({
                        interface_access_id: Joi.string().min(24).max(24).required().error(new Error('interface_access_id must be a valid Mongo ID.')),
                        interface_access_name: Joi.string().required()
                    })),
                    user_type:Joi.string().required(),
                    user_about:Joi.string(),
                    user_social_links:Joi.object({
                        twitter: Joi.string(),
                        facebook: Joi.string(),
                        linkedin: Joi.string(),
                    }),
                    user_office_address: Joi.array().items(Joi.object({
                        address_line1:Joi.string(),address_line2: Joi.string(),
                        address_line3: Joi.string(),area: Joi.string(),
                        city_name: Joi.string(),state_name: Joi.string(),
                        country_name: Joi.number(),region_name: Joi.string(),
                        pincode: Joi.string(),zip: Joi.string(),
                        telphone:Joi.string(),
                    })),
                    user_personal_address: Joi.array().items(Joi.object({
                        address_line1:Joi.string(),address_line2: Joi.string(),
                        address_line3: Joi.string(),area: Joi.string(),
                        city_name: Joi.string(),state_name: Joi.string(),
                        country_name: Joi.number(),region_name: Joi.string(),
                        pincode: Joi.string(),zip: Joi.string(),
                        telphone:Joi.string(),
                    })),
                    user_work_experience: Joi.array().items(Joi.object({
                        company:Joi.string(),
                        designation: Joi.string(),
                        is_current_exp: Joi.string(),
                        date_from:Joi.string().isoDate(),
                        date_to:Joi.string().isoDate(),
                        office_email:Joi.string().email()
                    })),
                    user_educational_qualification: Joi.array().items(Joi.object({
                        institutions:Joi.string(),
                        qualification: Joi.string(),
                        year_from: Joi.number(),
                        year_to:Joi.number()
                    })),
                    user_vendor_details:Joi.array().items(Joi.object({
                        vendor_id:Joi.string().min(24).max(24).required().error(new Error('vendor_id must be a valid Mongo ID.')),
                        vendor_name: Joi.string(),
                        assigned_date:Joi.string().isoDate().error(new Error('assigned_date must be a valid ISO Date.'))
                    })),
                    user_technical_competencies:Joi.array(),
                    user_futurebridge_relevancy :Joi.array(),
                    user_profile_picture:Joi.binary().encoding('base64').error(new Error('user_profile_picture must be a valid base64 encoding string.'))
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    //validate email id & login id
                    var login_id = (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '';
                    let isValidUser = await UsersController.checkIsUserExist(req.payload.user_email, login_id, '');
                    if (_.isEmpty(isValidUser)) {
                        // create Customer
                        const userId = await UsersController.create(req);
                        if (typeof userId._id !== "undefined") {
                            //  return success message
                            return h.response('success');
                        } else {
                            return Boom.badRequest('Error occured while creating GenX CMS User.');
                        }
                    } else {
                        isValidUser = JSON.parse(JSON.stringify(isValidUser));
                        if (isValidUser.user_email == req.payload.user_email) {
                            return h.response('email_exists');
                        }
                        if (isValidUser.user_login_id == login_id && !_.isEmpty(login_id)) {
                            return h.response('loginid_exists');
                        }
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }

    },
    {
        path: '/users',
        method: 'GET',
        options: {
            description: 'Get GenX CMS Users list',
            notes: "Returns an array of Users.\n\n Parameters :\n\n `filter` is an object with user's field as key and search keyword as its value `e.g { \"userFname\" : \"Jack\", \"userPersonalAddress.countryName\" : \"India\"}` \n\n `field` will be array of user's fields in camelCase `e.g [{ \"field\" : \"userFname\"},{ \"field\" : \"userLname\"},{ \"field\" : \"userEmail\"},{\"field\" : \"userSubscription\", \"filter\":{\"subscriptionProductServices.productName\":\"whatnext\"}}]`. If array is empty it will return all fields.",
            tags: ['api'],
            validate: {
                query: {
                    filter: Joi.object(
                        {
                            userFname: Joi.string().min(1).max(50),
                            userLname: Joi.string().min(1).max(50),
                            userEmail: Joi.string().email(),
                            userSocialLinks: Joi.object({
                                twitter: Joi.string(),
                                facebook: Joi.string(),
                                linkedin: Joi.string(),
                            }),
                            userTechnicalCompetencies: Joi.array(),
                            userFuturebridgeRelevancy : Joi.array(),
                            userVendorDetails: Joi.object({
                                vendorId: Joi.string().min(24).max(24).error(new Error('vendorId must be a valid Mongo ID.')),
                                vendorName: Joi.string()
                            }),
                            userType:Joi.string(),
                            userAccess: Joi.object({
                                interfaceAccessId: Joi.string().min(24).max(24).error(new Error('interfaceAccessId must be a valid Mongo ID.')),
                                interfaceAccessName: Joi.string()
                            }),
                        }
                    ),
                    field: Joi.array(),
                    sort: Joi.object({
                        field: Joi.string(), order: Joi.number().min(-1).max(1),
                    }),
                    limit: Joi.number().default(10),
                    skip: Joi.number(),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await UsersController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/users/{userId}',
        method: 'GET',
        options: {
            description: 'Get user By Id',
            notes: "Returns user.",
            tags: ['api'],
            validate: {
                query: {
                    userId:Joi.string().min(24).max(24).required().error(new Error('userId must be a valid Mongo ID.')),
                    field: Joi.array()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await UsersController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/users/{userId}',
        method: 'PUT',
        options: {
            description: 'Update GenX CMS User',
            notes: "Returns keyword `success` on succesfully user updation.\n\n Returns keyword `email_exists` if email id already exists.\n\n Returns keyword `loginid_exists` if login id already exists.",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    userId: Joi.string().min(24).max(24).required().error(new Error('Please provide valid User Id')),
                    user_fname: Joi.string().min(1).max(50).required(),
                    user_lname: Joi.string().min(1).max(50).required(),
                    user_email: Joi.string().email().required(),
                    user_access: Joi.array().items(Joi.object({
                        interface_access_id: Joi.string().min(24).max(24).required().error(new Error('interface_access_id must be a valid Mongo ID.')),
                        interface_access_name: Joi.string().required()
                    })),
                    user_type:Joi.string().required(),
                    user_about:Joi.string(),
                    user_social_links:Joi.object({
                        twitter: Joi.string(),
                        facebook: Joi.string(),
                        linkedin: Joi.string(),
                    }),
                    user_office_address: Joi.array().items(Joi.object({
                        address_line1:Joi.string(),address_line2: Joi.string(),
                        address_line3: Joi.string(),area: Joi.string(),
                        city_name: Joi.string(),state_name: Joi.string(),
                        country_name: Joi.number(),region_name: Joi.string(),
                        pincode: Joi.string(),zip: Joi.string(),
                        telphone:Joi.string(),
                    })),
                    user_personal_address: Joi.array().items(Joi.object({
                        address_line1:Joi.string(),address_line2: Joi.string(),
                        address_line3: Joi.string(),area: Joi.string(),
                        city_name: Joi.string(),state_name: Joi.string(),
                        country_name: Joi.number(),region_name: Joi.string(),
                        pincode: Joi.string(),zip: Joi.string(),
                        telphone:Joi.string(),
                    })),
                    user_work_experience: Joi.array().items(Joi.object({
                        company:Joi.string(),
                        designation: Joi.string(),
                        is_current_exp: Joi.string(),
                        date_from:Joi.string().isoDate(),
                        date_to:Joi.string().isoDate(),
                        office_email:Joi.string().email()
                    })),
                    user_educational_qualification: Joi.array().items(Joi.object({
                        institutions:Joi.string(),
                        qualification: Joi.string(),
                        year_from: Joi.number(),
                        year_to:Joi.number()
                    })),
                    user_vendor_details:Joi.array().items(Joi.object({
                        vendor_id:Joi.string().min(24).max(24).required().error(new Error('vendor_id must be a valid Mongo ID.')),
                        vendor_name: Joi.string(),
                        assigned_date:Joi.string().isoDate().error(new Error('assigned_date must be a valid ISO Date.'))
                    })),
                    user_technical_competencies:Joi.array(),
                    user_futurebridge_relevancy :Joi.array(),
                    user_profile_picture:Joi.binary().encoding('base64').error(new Error('user_profile_picture must be a valid base64 encoding string.'))
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    //validate email id & login id
                    var login_id = (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '';
                    let isValidUser = await UsersController.checkIsUserExist(req.payload.user_email, login_id, req.payload.userId);
                    if (_.isEmpty(isValidUser)) {
                        // update User
                        const result = await UsersController.update(req);
                        if (result) {
                            //  return success message
                            return h.response('success');
                        } else {
                            return Boom.badRequest('Error occured while updating User. No such User exist.');
                        }
                    } else {
                        isValidUser = JSON.parse(JSON.stringify(isValidUser));
                        if (isValidUser.user_email == req.payload.user_email) {
                            return h.response('email_exists');
                        }
                        if (isValidUser.user_login_id == login_id && !_.isEmpty(login_id)) {
                            return h.response('loginid_exists');
                        }
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }

    }
];