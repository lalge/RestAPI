//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;
ObjectId = Schema.ObjectId;
const UsersSchema = new Schema(
    {
        user_fname: String,
        user_registration_date: Date,
        user_work_experience : [{
            _id: false,
            date_to : Date,
            date_from : Date,
        }],
        user_vendor_details : [{
            _id: false,
            vendor_id : ObjectId,
            assigned_date : Date,
        }],
        user_access : [{
            _id: false,
            interface_access_id : ObjectId
        }]
        
    }, { strict: false,versionKey: false });

module.exports = Mongoose.model('gnx_users', UsersSchema,'gnx_users');