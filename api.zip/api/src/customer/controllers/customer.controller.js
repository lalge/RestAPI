//customer.controller.js
const CustomerModel = require('../models/customer.model');
const CustomerArchiveModel = require('../models/customerArchive.model');
const LogApiModel = require('../../logs/models/log-api.model');
const Functions = require('../../../libs/function');
const remoteAppDbService = require('../../services/remoteAppDbService');
const SubscriptionHistoryModel = require('../../subscription/models/subscriptionhistory.model');
const Mongoose = require('mongoose');
const _ = require('underscore');
const fs = require('fs');
const sha1 = require('sha1');

module.exports = {
    find: async (req) => {
        var pipeline = [];
        var where = {};
        _.mapObject(req.query.filter, function (val, key) {
            let obj = {};
            if (key === "id") {
                obj['_id'] = Mongoose.Types.ObjectId(val);
            } else {
                obj[Functions.decamelize(key)] = (_.isNumber(val)) ? val : new RegExp('^' + Functions.escapeRegExp(val) + '$', 'i');
            }
            if (typeof where['$and'] === 'undefined') {
                where['$and'] = [];
            }
            where['$and'].push(obj);
        });
        if (req.query.customerId) {
            if (typeof where['$and'] === 'undefined') {
                where['$and'] = [];
            }
            where['$and'].push({ _id: Mongoose.Types.ObjectId(req.query.customerId) });
        }

        var columns = {};
        var isFilterExist = false;
        if (req.query.field) {
            _.each(req.query.field, function (column) {
                field = Functions.decamelize(column.field);
                columns[field] = 1
                if (typeof column.filter !== "undefined") {
                    isFilterExist = true;
                }
            });
        }

        if (!_.isEmpty(where)) {
            pipeline.push({ $match: where });
        }
        if (!_.isEmpty(columns)) {
            pipeline.push({ $project: columns });
        }
        //pipeline.push({ $addFields: { score: { $meta: 'textScore' } } });
        //pipeline.push({ $sort: { user_active: -1, score: -1 } });

        if (typeof req.query.sort !== 'undefined') {
            pipeline.push({ $sort: req.query.sort });
        }
        if (typeof req.query.limit !== 'undefined') {
            pipeline.push({ $limit: req.query.limit });
        }
        if (typeof req.query.skip !== 'undefined') {
            pipeline.push({ $skip: req.query.skip });
        }
        // console.log('where',where);
        // console.log('pipeline',pipeline);
        var result = [];
        result = await CustomerModel.aggregate(pipeline, (err, docs) => {
            if (err) {
                console.log(err)
            }
        });
        // console.log("result retured",result);
        if (!_.isEmpty(result)) {
            _.each(result, function (record) {
                delete record.user_password;

                var image = record['user_profile_picture'];
                var imgBase64data = '';
                if (!_.isEmpty(image)) {
                    var img_file = process.env.BASE_PATH + '/public/assets-cms/customer/' + image;
                    if (fs.existsSync(img_file)) {
                        var buff = fs.readFileSync(img_file);
                        imgBase64data = buff.toString('base64');
                        record.user_profile_picture = imgBase64data;
                    }
                }
            });
        }
        // insert API log
        const apiLog = new LogApiModel({
            request_date: new Date(),
            request_params: req.query,
            request_api: req.path,
            response_count: result.length,
        });
        await apiLog.save();
        return result;
    },
    //create user
    create: async (req) => {
        var password = (!_.isEmpty(req.payload.user_password)) ? sha1(sha1(req.payload.user_password) + '::' + process.env.SALT) : '';
        var customer_data = {
            user_fname: req.payload.user_fname,
            user_lname: req.payload.user_lname,
            user_email: req.payload.user_email,
            user_password: password,
            user_login_id: (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '',
            user_relationship_manager_name: req.payload.user_relationship_manager_name,
            user_relationship_manager_email: req.payload.user_relationship_manager_email,
            btb_id: req.payload.btb_id,
            user_ip_address: (typeof req.payload.user_ip_address !== 'undefined') ? req.payload.user_ip_addresss : '',
            user_designation: req.payload.user_designation,
            user_active: req.payload.user_active,
            user_address_billing: (typeof req.payload.user_address_billing !== 'undefined') ? req.payload.user_address_billing : [],
            user_address_office: (typeof req.payload.user_address_office !== 'undefined') ? req.payload.user_address_office : [],
            user_address_service_use: (typeof req.payload.user_address_service_use !== 'undefined') ? req.payload.user_address_service_use : [],
            user_company: (typeof req.payload.user_company !== 'undefined') ? req.payload.user_company : [],
            user_social_links: (typeof req.payload.user_social_links !== 'undefined') ? req.payload.user_social_links : {},
            user_created_date: new Date(),
            user_last_modified_date: new Date(),
            user_payment_gateway_id: (typeof req.payload.user_payment_gateway_id !== 'undefined') ? req.payload.user_payment_gateway_id : {},
            created_by:(typeof req.payload.created_by !== 'undefined') ? req.payload.created_by : '',
        };
        var customer = new CustomerModel(customer_data);
        var result = await customer.save();
        console.log(result);
        result = JSON.parse(JSON.stringify(result));
        
        if (!_.isEmpty(result._id)) {

            let isWhatNextSubscription = false;
            if (typeof req.payload.user_platform !== 'undefined') {
                if (req.payload.user_platform == 'WhatNext') {
                    isWhatNextSubscription = true;
                }
            }
            if (isWhatNextSubscription) {
                //create same customer in WhatNext
                let user_company = (!_.isEmpty(customer_data.user_company)) ? customer_data.user_company[0]['company_name'] : '';
                delete customer_data.user_company;
                var wn_customer_data = { '_id': Mongoose.Types.ObjectId(result._id), ...customer_data };
                wn_customer_data.user_company = user_company;
                wn_customer_data.user_subscribe_dt = [];
                wn_customer_data.user_subscribe_industry = [];

                await Functions.updateWhatNextUser({
                    userId: Mongoose.Types.ObjectId(result._id), dataToUpdate: wn_customer_data
                });
                // await remoteAppDbService.setDataInRemoteAppDb({
                //     remoteAppName: 'whatnext', // whatnext, industryinsider
                //     storageName: 'inx_user',
                //     dbMethod: 'mongoInsert', // mongoUpdate, mongoInsert
                //     where: {},
                //     data: wn_customer_data
                // });
            }


            const apiLog = new LogApiModel({
                // insert API log
                request_date: new Date(),
                request_params: req.payload,
                request_api: req.path,
                response_count: result.length,
            });
            await apiLog.save();

            return result;

        } else {
            return [];
        }
    },
    update: async (req) => {
        var customer_data = {
            user_last_modified_date: new Date()
        };
        if (typeof req.payload.user_fname !== 'undefined') {
            if (!_.isEmpty(req.payload.user_fname)) {
                customer_data.user_fname = req.payload.user_fname;
            }
        }
        if (typeof req.payload.user_lname !== 'undefined') {
            customer_data.user_lname = req.payload.user_lname;
        }
        if (typeof req.payload.user_email !== 'undefined') {
            customer_data.user_email = req.payload.user_email;
        }
        if (typeof req.payload.user_relationship_manager_name !== 'undefined') {
            customer_data.user_relationship_manager_name = req.payload.user_relationship_manager_name;
        }
        if (typeof req.payload.user_relationship_manager_email !== 'undefined') {
            customer_data.user_relationship_manager_email = req.payload.user_relationship_manager_email;
        }
        if (typeof req.payload.btb_id !== 'undefined') {
            customer_data.btb_id = req.payload.btb_id;
        }
        if (typeof req.payload.user_designation !== 'undefined') {
            customer_data.user_designation = req.payload.user_designation;
        }
        if (typeof req.payload.user_login_id !== 'undefined') {
            customer_data.user_login_id = req.payload.user_login_id;
        }
        if (typeof req.payload.user_address_office !== 'undefined') {
            customer_data.user_address_office = req.payload.user_address_office;
        }
        if (typeof req.payload.user_address_billing !== 'undefined') {
            customer_data.user_address_billing = req.payload.user_address_billing;
        }
        if (typeof req.payload.user_address_service_use !== 'undefined') {
            customer_data.user_address_service_use = req.payload.user_address_service_use;
        }
        if (typeof req.payload.user_company !== 'undefined') {
            customer_data.user_company = req.payload.user_company;
        }
        if (typeof req.payload.user_social_links !== 'undefined') {
            customer_data.user_social_links = req.payload.user_social_links;
        }
        if (typeof req.payload.user_password !== "undefined") {
            customer_data.user_password = sha1(sha1(req.payload.user_password) + '::' + process.env.SALT);
        }
        if (typeof req.payload.user_active !== "undefined") {
            customer_data.user_active = req.payload.user_active;
        }
        if (typeof req.payload.user_payment_gateway_id !== "undefined") {
            customer_data.user_payment_gateway_id = req.payload.user_payment_gateway_id;
        }
        if (typeof req.payload.created_by !== "undefined") {
            customer_data.created_by = req.payload.created_by;
        }
        

        var result = await CustomerModel.findByIdAndUpdate(Mongoose.Types.ObjectId(req.payload.customerId), { $set: customer_data }, { new: true });

        if (typeof req.payload.user_platform !== 'undefined') {
            if (req.payload.user_platform == 'WhatNext') {
                //update  customer in WhatNext
                let user_company = (!_.isEmpty(customer_data.user_company)) ? customer_data.user_company[0]['company_name'] : '';
                delete customer_data.user_company;
                var wn_customer_data = { '_id': Mongoose.Types.ObjectId(result._id), ...customer_data };
                wn_customer_data.user_company = user_company;
                

                await Functions.updateWhatNextUser({
                    userId: Mongoose.Types.ObjectId(result._id), dataToUpdate: wn_customer_data
                });

                // await remoteAppDbService.setDataInRemoteAppDb({
                //     remoteAppName: 'whatnext',
                //     storageName: 'inx_user',
                //     dbMethod: 'mongoUpdate',
                //     where: { _id: result._id },
                //     data: { $set: wn_customer_data }
                // });
            }
        }
        

        const apiLog = new LogApiModel({
            // insert API log
            request_date: new Date(),
            request_params: req.payload,
            request_api: req.path,
            response_count: result.length,
        });
        await apiLog.save();
        //console.log(result);
        return result;

    },
    /**
     * check if customer already exists in our DB.
     * 
     * @param Email_id
     * @param Login_id
     * @param Customer Mongo Id (for PUT request in POST request it will be empty)
     */
    checkIsCustomerExist: async (email_id, login_id, customer_id) => {
        //create dynamic query to check of customer's email or login id exists
        var query = {};
        query['$and'] = [];
        if (!_.isEmpty(login_id)) {
            query['$or'] = [];
            query['$or'].push({ 'user_email': email_id }, { 'user_login_id': login_id });
            delete query['$and'];
        } else {
            query['$and'].push({ 'user_email': email_id });
        }
        if (!_.isEmpty(customer_id)) {
            if (_.isEmpty(query['$and'])) {
                query['$and'] = [];
            }
            query['$and'].push({ '_id': { '$ne': Mongoose.Types.ObjectId(customer_id) } });
        }
        var customer = await CustomerModel.findOne(query);
        if (_.isEmpty(customer)) {
            return [];
        } else {
            return customer;
        }
    },
    getSubscriptionHistory: async (req) => {

        var where = {};
        if (typeof req.query.id != "undefined") {
            if (!_.isEmpty(req.query.id)) {
                where.user_id = Mongoose.Types.ObjectId(req.query.id);
            }
        }
        if (typeof req.query.subscriptionId != "undefined") {
            if (!_.isEmpty(req.query.subscriptionId)) {
                where.subscription_id = Mongoose.Types.ObjectId(req.query.subscriptionId);
            }
        }
        var result = [];
        result = await SubscriptionHistoryModel.find(where);
        return result;


    },
    delete: async (req) => {

        // move old recod to archive
        let customer_id = Mongoose.Types.ObjectId(req.payload.customerId)
        let customer = await CustomerModel.findOne(customer_id);
        if (customer) {
            var customerArchive = new CustomerArchiveModel(customer);
            var customerArchiveSaved = await customerArchive.save();
            if (customerArchiveSaved) {
                // delete from customer 
                await CustomerModel.findOneAndRemove(customer_id);
                return { success: 'delete', customerId: customerId };
            }

        }
        return { success: 'delete', customerId: '' };
        // 

    }


};