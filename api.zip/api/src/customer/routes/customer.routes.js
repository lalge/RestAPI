//Customer.routes.js
const CustomerController = require('../controllers/customer.controller');
const SubscriptionHistoryController = require('../../subscription/controllers/subscriptionhistory.controller');
const ProductServicesController = require('../../default/controllers/productservices.controller');
const Functions = require('../../../libs/function');
var Joi = require('joi');
const Boom = require('boom');
const _ = require('underscore');
module.exports = [
    {
        path: '/customers',
        method: 'GET',
        options: {
            description: 'Get Customers list',
            notes: "Returns an array of Customers.\n\n Parameters :\n\n `filter` is an object with customer's field as key and search keyword as its value `e.g { \"userFname\" : \"Jack\", \"userPersonalAddress.countryName\" : \"Japan\"}` \n\n `field` will be array of customer's fields in camelCase `e.g [{ \"field\" : \"userFname\"},{ \"field\" : \"userLname\"},{ \"field\" : \"userEmail\"},{\"field\" : \"userSubscription\", \"filter\":{\"subscriptionProductServices.productName\":\"whatnext\"}}]`. If array is empty it will return all fields.",
            tags: ['api'],
            validate: {
                query: {
                    filter: Joi.object(
                        {
                            userFname: Joi.string().min(1).max(50),
                            userLname: Joi.string().min(1).max(50),
                            userEmail: Joi.string().email(),
                            userRelationshipManagerName: Joi.string().min(1).max(100),
                            btbTd: Joi.string(),
                            userCompany: Joi.object({
                                companyId: Joi.string().min(24).max(24).error(new Error('companyId must be a valid Mongo ID.')),
                                companyName: Joi.string(),
                            }),
                            userSocialLinks: Joi.object({
                                twitter: Joi.string(),
                                facebook: Joi.string(),
                                linkedin: Joi.string(),
                            }),
                            userSubscription: Joi.object({
                                dtName: Joi.string(),
                                subscriptionProductServices: Joi.object({
                                    productId: Joi.string().min(24).max(24).error(new Error('productId must be a valid Mongo ID.')),
                                    productName: Joi.string(),
                                })
                            }),
                        }
                    ),
                    field: Joi.array(),
                    sort: Joi.object({
                        field: Joi.string(), order: Joi.number().min(-1).max(1),
                    }),
                    limit: Joi.number().default(10),
                    skip: Joi.number(),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await CustomerController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/customers/{customerId}',
        method: 'GET',
        options: {
            description: 'Get Customer By Id',
            notes: "Returns Customer.",
            tags: ['api'],
            validate: {
                query: {
                    customerId: Joi.string().min(24).max(24).required().error(new Error('customerId must be required and it shoudl be a valid Mongo ID String.')),
                    field: Joi.array()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    const result = await CustomerController.find(req);
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/customers',
        method: 'POST',
        options: {
            description: 'Create Customer',
            notes: "Returns customerId  on succesfully customer creation.\n\n Returns keyword `email_exists` if email id already exists.\n\n Returns keyword `loginid_exists` if login id already exists.",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    user_fname: Joi.string().min(1).max(50).required(),
                    user_lname: Joi.string().min(1).max(50).allow(''),
                    user_email: Joi.string().email().required(),
                    user_password: Joi.string(),
                    user_relationship_manager_name: Joi.string().min(1).max(100),
                    user_relationship_manager_email: Joi.string().email(),
                    btb_id: Joi.string(),
                    user_designation: Joi.string().allow(''),
                    user_company: Joi.array().items(Joi.object({
                        company_id: Joi.string().allow(''),
                        company_name: Joi.string().allow(''),
                    })),
                    user_profile_picture: Joi.binary().encoding('base64').error(new Error('user_profile_picture must be a valid base64 encoding string.')),
                    user_address_office: Joi.array().items(Joi.object({
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                    })),
                    user_address_billing: Joi.array().items(Joi.object({
                        fname: Joi.string(), lname: Joi.string().allow(''),
                        email: Joi.string().allow(''), company_name: Joi.string().allow(''),
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                        vat_no: Joi.string().allow('')
                    })),
                    user_address_service_use: Joi.array().items(Joi.object({
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                    })),
                    user_social_links: Joi.object({
                        twitter: Joi.string(),
                        facebook: Joi.string(),
                        linkedin: Joi.string(),
                    }),
                    user_payment_gateway_id: Joi.string(),
                    user_preference: Joi.object({
                        keep_sections_collapsed: Joi.string(),
                        keep_sections_collapsed_freez: Joi.string(),
                    }),
                    created_by: Joi.string().min(24).max(24).allow('').error(new Error('Please provide valid Mongo Id')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                let response = { 'response': 'success' };
                try {
                    //validate email id & login id
                    var login_id = (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '';
                    
                    let isValidCustomer = await CustomerController.checkIsCustomerExist(req.payload.user_email, login_id, '');
                    
                    if (_.isEmpty(isValidCustomer)) {
                        // create Customer
                        const customerId = await CustomerController.create(req);
                        console.log("customerId",customerId);
                        if (typeof customerId._id !== "undefined") {
                            //  return success message
                            response = { 'response': 'success', customerId: customerId._id };
                        } else {
                            return h.response(Boom.badRequest('Error occured while creating Customer.'));
                        }
                    } else {
                        isValidCustomer = JSON.parse(JSON.stringify(isValidCustomer));
                        if (isValidCustomer.user_email == req.payload.user_email) {
                            response = { 'response': 'email_exists' };
                        }
                        if (isValidCustomer.user_login_id == login_id && !_.isEmpty(login_id)) {
                            response = { 'response': 'loginid_exists' };
                        }
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }
                return h.response(response).code(200);

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
        }
    },
    {
        path: '/customers/{customerId}',
        method: 'PUT',
        options: {
            description: 'Update Customer',
            notes: "Returns keyword `success` on succesfully customer updation.\n\n Returns keyword `email_exists` if email id already exists.\n\n Returns keyword `loginid_exists` if login id already exists.",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    customerId: Joi.string().min(24).max(24).required().error(new Error('Please provide valid Customer Id')),
                    user_fname: Joi.string().min(1).max(50),
                    user_lname: Joi.string().min(1).max(50).allow(''),
                    user_email: Joi.string().email(),
                    user_password: Joi.string().allow(''),
                    user_relationship_manager_name: Joi.string().min(1).max(100),
                    user_relationship_manager_email: Joi.string().email(),
                    btb_id: Joi.string(),
                    user_designation: Joi.string().allow('', null),
                    user_profile_picture: Joi.binary().encoding('base64').error(new Error('user_profile_picture must be a valid base64 encoding string.')),
                    user_company: Joi.array().items(Joi.object({
                        company_id: Joi.string().allow(''),
                        company_name: Joi.string().allow(''),
                    })),
                    user_address_office: Joi.array().items(Joi.object({
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                    })),
                    user_address_billing: Joi.array().items(Joi.object({
                        fname: Joi.string(), lname: Joi.string().allow(''),
                        email: Joi.string().allow(''), company_name: Joi.string().allow(''),
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                        vat_no: Joi.string().allow('')
                    })),
                    user_address_service_use: Joi.array().items(Joi.object({
                        phone_isd: Joi.string().allow(''), phone: Joi.string().allow(''),
                        address1: Joi.string().allow(''), address2: Joi.string().allow(''),
                        city: Joi.string().allow(''), state: Joi.string().allow(''),
                        country: Joi.string().allow(''), region_name: Joi.string().allow(''),
                        zip_code: Joi.string().allow(''), fax: Joi.string().allow(''),
                    })),
                    user_social_links: Joi.object({
                        twitter: Joi.string(),
                        facebook: Joi.string(),
                        linkedin: Joi.string(),
                    }),
                    user_payment_gateway_id: Joi.string(),
                    user_preference: Joi.object({
                        keep_sections_collapsed: Joi.string(),
                        keep_sections_collapsed_freez: Joi.string(),
                    }),
                    created_by: Joi.string().min(24).max(24).allow('').error(new Error('Please provide valid Mongo Id')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                let response = { 'response': 'success' };
                try {
                    //validate email id & login id
                    var login_id = (typeof req.payload.user_login_id !== 'undefined') ? req.payload.user_login_id : '';
                    let isValidCustomer = await CustomerController.checkIsCustomerExist(req.payload.user_email, login_id, req.payload.customerId);
                    if (_.isEmpty(isValidCustomer)) {
                        //console.log('isValidCustomer', isValidCustomer);
                        // update Customer
                        const result = await CustomerController.update(req);
                        if (result) {
                            //  return success message
                            response = { 'response': 'success' };
                        } else {
                            return Boom.badRequest('Error occured while updating Customer. No such Customer exist.');
                        }
                    } else {
                        isValidCustomer = JSON.parse(JSON.stringify(isValidCustomer));
                        if (isValidCustomer.user_email == req.payload.user_email) {
                            response = { 'response': 'email_exists' };
                            return h.response('email_exists');
                        }
                        if (isValidCustomer.user_login_id == login_id && !_.isEmpty(login_id)) {
                            response = { 'response': 'loginid_exists' };
                        }
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }
                return h.response(response).code(200);


            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/customers/{customerId}/subscription-history',
        method: 'GET',
        options: {
            description: 'Get Customer\'s Subscription history',
            notes: 'Returns an array of Subscription history. \n\n Parameters :\n\n `customerId` is an object id of Customer\n\n `subscription_id` is an object id of Subscription package.',
            tags: ['api'],
            validate: {
                query: {
                    id: Joi.string().min(24).max(24).error(new Error('history id must be a valid Mongo ID.')),
                    customerId: Joi.string().min(24).max(24).error(new Error('customerId must be a valid Mongo ID.')),
                    subscriptionId: Joi.string().min(24).max(24).error(new Error('Subscription Id must be a valid Mongo ID.'))
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {

                req.query.user_id = req.query.customerId;
                const result = await SubscriptionHistoryController.find(req);
                try {
                    return h.response(result);
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/customers/{customerId}/subscription-history',
        method: 'POST',
        options: {
            description: 'Create Subscription History',
            notes: "Returns subscriptionHistoryId  on succesfully subscription history creation.\n\n Returns keyword `product_not_exist` if `subscription_product_services.product_id` does not exists.",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    customerId: Joi.string().min(24).max(24).required().error(new Error('user_id must be a valid Mongo ID.')),
                    subscription_id: Joi.string().min(24).max(24).required().error(new Error('subscription_id must be a valid Mongo ID.')),
                    invoice_number: Joi.string().required(),
                    subscription_name: Joi.string().required(),
                    subscription_type: Joi.string().required(),
                    subscription_purchased_date: Joi.date(),
                    subscription_start_date: Joi.date(),
                    subscription_end_date: Joi.date(),
                    subscription_product_services: Joi.object().keys({
                        product_id: Joi.string().min(24).max(24).required().error(new Error('product_id must be a valid Mongo ID.')),
                        product_name: Joi.string().required(),
                    }),
                    subscription_package: Joi.object().required(),
                    subscription_pricing: Joi.object().required(),
                    payment_details: Joi.object().required(),
                    payment_mode: Joi.string().required(),
                    subscription_status: Joi.string(),
                    subscription_usage_limit: Joi.object()
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                let response = { 'response': 'success' };
                try {
                    //validate product_id
                    let isValidProduct = await ProductServicesController.find({ 'query': { 'product_id': req.payload.subscription_product_services.product_id.str } });
                    //console.log('isValidProduct',isValidProduct);
                    if (!_.isEmpty(isValidProduct)) {
                        req.payload.user_id = req.payload.customerId;
                        // create subscription history
                        const historyId = await SubscriptionHistoryController.create(req);
                        if (typeof historyId._id !== "undefined") {
                            //  return success message
                            response = { 'response': 'success', subscriptionHistoryId: historyId._id };
                        } else {
                            return Boom.badRequest('Error occured while creating subscription history.');
                        }
                    } else {
                        response = { 'response': 'subscription_product_services Not Found' };
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }
                return h.response(response);
            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
    {
        path: '/customers/{customerId}',
        method: 'DELETE',
        options: {
            description: 'Delete Customer',
            notes: "Returns keyword `success` on succesfully customer deleation",
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    customerId: Joi.string().min(24).max(24).required().error(new Error('Please provide valid Customer Id')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    //validate email id & login id
                    const result = await CustomerController.delete(req);
                    if (result) {
                        return h.response(result).code(200);
                    } else {
                        return Boom.badRequest('Error occured while updating Customer. No such Customer exist.');
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }

        }
    },
];