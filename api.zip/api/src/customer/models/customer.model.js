//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;
ObjectId = Schema.ObjectId;
const CustomerSchema = new Schema(
    {
        user_fname: String,
    }, { strict: false,versionKey: false });

module.exports = Mongoose.model('gnx_customer', CustomerSchema,'gnx_customer');