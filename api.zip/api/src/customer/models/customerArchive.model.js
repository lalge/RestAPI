//import the mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;
ObjectId = Schema.ObjectId;
const CustomerArchiveSchema = new Schema(
    {
        user_fname: String,
    }, { strict: false,versionKey: false });

module.exports = Mongoose.model('gnx_customer_archive', CustomerArchiveSchema,'gnx_customer_archive');