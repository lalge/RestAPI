const EmailTemplate = require('email-templates');
const nodemailer = require('nodemailer');
const path = require('path');
const templatesDir = path.resolve(__dirname, '../../templates/email');;
const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_SERVER_HOST,
    port: process.env.EMAIL_SERVER_PORT,
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.EMAIL_AUTH_USERNAME, // generated ethereal user
        pass: process.env.EMAIL_AUTH_PASSWORD, // generated ethereal password
    },

});
const randomstring = require('randomstring')
const Mongoose = require('mongoose');
const remoteAppDbService = require('../../services/remoteAppDbService');
const sha1 = require('sha1');
const _ = require('underscore');
const Functions = require('../../../libs/function');
const fs = require('fs');
const axios = require('axios')
const request = require('request')
module.exports = {
    sendCustomerLoginCredentials: async (req) => {

        let CustomerModel = require('../../customer/models/customer.model');

        // check record exists
        let isRecordFound = await CustomerModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.customerId) });
        isRecordFound = isRecordFound.toObject();
        if (_.isEmpty(isRecordFound)) {
            return { response: 'Record not found' };
        }
        if (_.isEmpty(isRecordFound.user_email)) {
            return { response: 'Email is empty for selected Record' };
        }


        // regenerate password
        let password = randomstring.generate({
            length: 7,
            charset: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$'
        });
        let passwordEncrypted = sha1(sha1(password) + '::' + process.env.SALT)

        // Update new password for customer
        await CustomerModel.findByIdAndUpdate(Mongoose.Types.ObjectId(req.payload.customerId),
            {
                $set:
                {
                    user_password: passwordEncrypted
                }
            }, { new: true });


        let templatePath, emailFrom, emailTo, emailSubject, productUrl, receiptUrl = '';
        emailTo = isRecordFound.user_email;


        // load template as per product platform 
        var subscription = [];
        if (req.payload.productPlatfom == 'WhatNext') {
            emailSubject = 'WhatNext - Login Credentials'
            templatePath = path.join(templatesDir, 'login-credentials')
            emailFrom = 'support@whatnextglobal.com'

            // update customer password in product db
            await remoteAppDbService.setDataInRemoteAppDb({
                remoteAppName: 'whatnext', // whatnext, industryinsider
                storageName: 'inx_user',
                dbMethod: 'mongoUpdate', // mongoUpdate, mongoInsert
                where: { _id: Mongoose.Types.ObjectId(req.payload.customerId) },
                data: {
                    $set:
                    {
                        user_password: passwordEncrypted
                    }
                }
            });
            productUrl = process.env.PRODUCT_WHATNEXT;
        } else if (req.payload.productPlatfom == 'IndustryInsider') {
            templatePath = path.join(templatesDir, 'login-credentials')
            emailFrom = 'support@whatnextglobal.com'
            productUrl = process.env.PRODUCT_INDUSTRY_INSIDER;

            await remoteAppDbService.setDataInRemoteAppDb({
                remoteAppName: 'industryinsider', // whatnext, industryinsider
                storageName: 'inx_user',
                dbMethod: 'mongoUpdate', // mongoUpdate, mongoInsert
                where: { _id: Mongoose.Types.ObjectId(req.payload.customerId) },
                data: {
                    $set:
                    {
                        user_password: passwordEncrypted
                    }
                }
            });
        } else if (req.payload.productPlatfom == 'GenNx') {
            templatePath = path.join(templatesDir, 'login-credentials')
            emailFrom = 'support@whatnextglobal.com'
            productUrl = process.env.PRODUCT_GENNX;
        }

        // Get Subscription details  from history if provided
        if (req.payload.subscriptionHistoryId) {
            // 
            let SubscriptionHistoryModel = require('../../subscription/models/subscriptionhistory.model');
            let subscriptionHistory = await SubscriptionHistoryModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.subscriptionHistoryId) });
            subscriptionHistory = subscriptionHistory.toObject();

            let packageDetail = '';
            for (var itemKey in subscriptionHistory.subscription_package) {
                packageDetail += '<div>';
                if (itemKey == 'analyst_hours') {
                    packageDetail += ' <b>Analyst Hours :</b> ' + subscriptionHistory.subscription_package[itemKey];
                } else if (itemKey == 'technology') {
                    let technology = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.dt_name;
                    });
                    packageDetail += ' <b>Technology :</b> ' + technology.join(', ');
                } else if (itemKey == 'industry') {
                    let industries = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.industry_name;
                    });
                    packageDetail += ' <b>Industry :</b> ' + industries.join(', ');
                }
                packageDetail += '</div>';
            }
            subscription.push({
                subscription_name: subscriptionHistory.subscription_name,
                subscription_type: subscriptionHistory.subscription_type,
                package_detail: packageDetail,
                start_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_start_date),
                end_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_end_date),

            });
            //          get payment receipt
            if (typeof subscriptionHistory.payment_details.receipt_url !== 'undefined') {
                receiptUrl = subscriptionHistory.payment_details.receipt_url;
            }
        }



        const email = new EmailTemplate({
            // uncomment below to send emails in development/test env:
            // send: true
            transport: transporter,
            views: {
                options: {
                    extension: 'handlebars'
                }
            }
        });

        // console.dir(subscription);
        // return subscription;
        const templates = await email.render(templatePath,
            {
                user_name: isRecordFound.user_fname + ' ' + isRecordFound.user_lname,
                user_email: isRecordFound.user_email,
                product_url: process.env.PRODUCT_WHATNEXT_WEBSITE,
                password: password,
                subscription: (req.payload.subscriptionHistoryId) ? subscription : [],
                receipt_url: receiptUrl
            });

        // console.log(templates);
        let response = '';
        try {
            let info = transporter.sendMail({
                from: emailFrom,
                to: emailTo,
                subject: emailSubject,
                html: templates
            });
            // response = templates//'email sent';
            response = 'email sent';

        } catch (error) {
            response = 'error in sending email';
        }
        return { response: response };
    },
    sendUserLoginCredentials: async (req) => {
        response = 'To Be Developed..';
        return { response: response };
    },
    sendCustomerSubscriptions: async (req) => {

        let CustomerModel = require('../../customer/models/customer.model');

        // check record exists
        let isRecordFound = await CustomerModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.customerId) });
        isRecordFound = isRecordFound.toObject();
        if (_.isEmpty(isRecordFound)) {
            return { response: 'Record not found' };
        }
        if (_.isEmpty(isRecordFound.user_email)) {
            return { response: 'Email is empty for selected Record' };
        }

        let templatePath, emailFrom, emailTo, emailSubject, productUrl, receiptUrl = '';
        emailTo = isRecordFound.user_email;
        // load template as per product platform 
        var subscription = [];
        if (req.payload.productPlatfom == 'WhatNext') {
            emailSubject = 'WhatNext - Subscription Details'
            templatePath = path.join(templatesDir, 'subscription')
            emailFrom = 'support@whatnextglobal.com'

            productUrl = process.env.PRODUCT_WHATNEXT;
        } else if (req.payload.productPlatfom == 'IndustryInsider') {
            templatePath = path.join(templatesDir, 'subscription')
            emailFrom = 'support@whatnextglobal.com'
            productUrl = process.env.PRODUCT_INDUSTRY_INSIDER;
        } else if (req.payload.productPlatfom == 'GenNx') {
            templatePath = path.join(templatesDir, 'subscription')
            emailFrom = 'support@whatnextglobal.com'
            productUrl = process.env.PRODUCT_GENNX;
        }

        // Get Subscription details  from history if provided
        let response = '';
        if (req.payload.subscriptionHistoryId) {
            // 
            let SubscriptionHistoryModel = require('../../subscription/models/subscriptionhistory.model');
            let subscriptionHistory = await SubscriptionHistoryModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.subscriptionHistoryId) });
            subscriptionHistory = subscriptionHistory.toObject();

            let packageDetail = '';
            for (var itemKey in subscriptionHistory.subscription_package) {
                packageDetail += '<div>';
                if (itemKey == 'analyst_hours') {
                    packageDetail += ' <b>Analyst Hours :</b> ' + subscriptionHistory.subscription_package[itemKey];
                } else if (itemKey == 'technology') {
                    let technology = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.dt_name;
                    });
                    if (technology.length > 0)
                        packageDetail += ' <b>Technology :</b> ' + technology.join(', ');
                } else if (itemKey == 'industry') {
                    let industries = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.industry_name;
                    });
                    if (industries.length > 0)
                        packageDetail += ' <b>Industry :</b> ' + industries.join(', ');
                }
                packageDetail += '</div>';
            }
            subscription.push({
                subscription_name: subscriptionHistory.subscription_name,
                subscription_type: subscriptionHistory.subscription_type,
                package_detail: packageDetail,
                start_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_start_date),
                end_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_end_date),
                subscription_create_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_purchased_date),
                subscription_status: subscriptionHistory.subscription_status
            });

            //          get payment receipt
            if (typeof subscriptionHistory.payment_details.receipt_url !== 'undefined') {
                receiptUrl = subscriptionHistory.payment_details.receipt_url;
            }
            const email = new EmailTemplate({
                // uncomment below to send emails in development/test env:
                // send: true
                transport: transporter,
                views: {
                    options: {
                        extension: 'handlebars'
                    }
                }
            });

            // console.dir(subscription);
            // return subscription;
            const templates = await email.render(templatePath,
                {
                    user_name: isRecordFound.user_fname + ' ' + isRecordFound.user_lname,
                    user_email: isRecordFound.user_email,
                    product_url: process.env.PRODUCT_WHATNEXT_WEBSITE,
                    subscription: (req.payload.subscriptionHistoryId) ? subscription : [],
                    receipt_url: receiptUrl,
                    subscription_status: subscriptionHistory.subscription_status
                });

            // console.log(templates);
            try {
                let info = transporter.sendMail({
                    from: emailFrom,
                    to: emailTo,
                    subject: emailSubject,
                    html: templates
                });
                // response = templates//'email sent';
                response = 'email sent';

            } catch (error) {
                response = 'error in sending email';
            }
            // send mail to customer's relationship manger
            if (req.payload.productPlatfom == 'WhatNext') {
                if (req.payload.relationShipManager) {
                    let relationShipManager = req.payload.relationShipManager;
                    templatePath = path.join(templatesDir, 'subscription-relationship-manager')
                    const email = new EmailTemplate({
                        // uncomment below to send emails in development/test env:
                        // send: true
                        transport: transporter,
                        views: {
                            options: {
                                extension: 'handlebars'
                            }
                        }
                    });

                    // console.dir(subscription);
                    // return subscription;
                    const templates = await email.render(templatePath,
                        {
                            user_name: isRecordFound.user_fname + ' ' + isRecordFound.user_lname,
                            user_email: isRecordFound.user_email,
                            product_url: process.env.PRODUCT_WHATNEXT_WEBSITE,
                            subscription: (req.payload.subscriptionHistoryId) ? subscription : [],
                            subscription_status: subscriptionHistory.subscription_status,
                        });

                    // console.log(relationShipManager);
                    try {
                        if (relationShipManager.user_email) {
                            let info = transporter.sendMail({
                                from: emailFrom,
                                to: relationShipManager.user_email,
                                subject: 'WhatNext - New Subscription',
                                html: templates
                            });
                        }
                        // response = templates//'email sent';
                        response = 'email sent';

                    } catch (error) {
                        response = 'error in sending email';
                    }
                }
            }

        }
        return { response: response };
    },
    sendCustomerInvoice: async (req) => {

        let CustomerModel = require('../../customer/models/customer.model');

        // check record exists
        let isRecordFound = await CustomerModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.customerId) });
        if (_.isEmpty(isRecordFound)) {
            return { response: 'Record not found' };
        }
        isRecordFound = isRecordFound.toObject();
        if (_.isEmpty(isRecordFound.user_email)) {
            return { response: 'Email is empty for selected Record' };
        }
        let templatePath, emailFrom, emailTo, emailSubject, paymentLinkUrl, invoicePdf = '';
        let emailAttachements = [];
        emailTo = isRecordFound.user_email;

        // load template as per product platform 
        var subscription = [];
        if (req.payload.productPlatfom == 'WhatNext') {
            emailSubject = 'WhatNext - Subscription Invoice Details'
            templatePath = path.join(templatesDir, 'invoice-payment-link')
            emailFrom = 'support@whatnextglobal.com'
            productUrl = process.env.PRODUCT_WHATNEXT;
        } else if (req.payload.productPlatfom == 'IndustryInsider') {

        } else if (req.payload.productPlatfom == 'GenNx') {

        }

        // Get Subscription details  from history if provided
        let response = '';
        if (req.payload.subscriptionHistoryId) {
            // 
            let SubscriptionHistoryModel = require('../../subscription/models/subscriptionhistory.model');
            let subscriptionHistory = await SubscriptionHistoryModel.findOne({ _id: Mongoose.Types.ObjectId(req.payload.subscriptionHistoryId) });

            subscriptionHistory = subscriptionHistory.toObject();
            // console.log('subscriptionHistory',subscriptionHistory);


            let packageDetail = '';
            for (var itemKey in subscriptionHistory.subscription_package) {
                packageDetail += '<div>';
                if (itemKey == 'analyst_hours') {
                    packageDetail += ' <b>Analyst Hours :</b> ' + subscriptionHistory.subscription_package[itemKey];
                } else if (itemKey == 'technology') {
                    // console.log(subscriptionHistory.subscription_package[itemKey]);
                    let technology = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.dt_name;
                    });
                    if (technology.length > 0)
                        packageDetail += ' <b>Technology :</b> ' + technology.join(', ');
                } else if (itemKey == 'industry') {
                    let industries = _.map(subscriptionHistory.subscription_package[itemKey], function (item) {
                        return item.industry_name;
                    });
                    if (industries.length > 0)
                        packageDetail += ' <b>Industry :</b> ' + industries.join(', ');
                }
                packageDetail += '</div>';
            }

            subscription.push({
                subscription_name: subscriptionHistory.subscription_name,
                subscription_type: subscriptionHistory.subscription_type,
                package_detail: packageDetail,
                start_date: (subscriptionHistory.subscription_start_date) ? Functions.covertDateToLocalTime(subscriptionHistory.subscription_start_date) : '',
                end_date: (subscriptionHistory.subscription_end_date) ? Functions.covertDateToLocalTime(subscriptionHistory.subscription_end_date) : '',
                subscription_status: subscriptionHistory.subscription_status,
                subscription_create_date: Functions.covertDateToLocalTime(subscriptionHistory.subscription_purchased_date),

            });
            paymentLinkUrl = subscriptionHistory.payment_details.payment_link;

            // download invoice pdf

            if (typeof subscriptionHistory.payment_details.invoice_details !== 'undefined') {
                let invoice_details = subscriptionHistory.payment_details.invoice_details;

                if (typeof invoice_details.invoice_pdf !== 'undefined') {
                    invoicePdf = invoice_details.invoice_pdf;
                }
                if (invoicePdf != '') {
                    // const fileName = 'Invoice-' + subscriptionHistory.invoice_number.replace("/", "-") + '.pdf';
                    // const fileLocalPath = process.env.BASE_PATH + '/public/temp/' + fileName; 

                    // const response = await axios.get(invoicePdf, { responseType: 'blob' });
                    // console.log(response.data);
                    // await fs.writeFileSync(fileLocalPath, response.data, (err) => {
                    //     if (err) throw err;
                    //     console.log('The file has been saved!');
                    // });

                    // let pdfBuffer = await request.get({ uri: invoicePdf, strictSSL: false });
                    // console.log(pdfBuffer);
                    // console.log("Writing downloaded PDF file to " + fileLocalPath + "...");
                    // fs.writeFileSync(fileLocalPath, pdfBuffer);



                    // emailAttachements.push({
                    //     filename: fileName,
                    //     path: fileLocalPath
                    // })
                }
            }

            const email = new EmailTemplate({
                // uncomment below to send emails in development/test env:
                // send: true
                transport: transporter,
                views: {
                    options: {
                        extension: 'handlebars',

                    }

                }
            });

            // console.dir(subscription);
            // return subscription;
            const templates = await email.render(templatePath,
                {
                    user_name: isRecordFound.user_fname + ' ' + isRecordFound.user_lname,
                    user_email: isRecordFound.user_email,
                    product_url: process.env.PRODUCT_WHATNEXT_WEBSITE,
                    subscription: subscription,
                    payment_link: paymentLinkUrl,
                    invoice_pdf: invoicePdf,
                    subscription_status: subscriptionHistory.subscription_status
                });
            try {
                let info = transporter.sendMail({
                    from: emailFrom,
                    to: emailTo,
                    subject: emailSubject,
                    html: templates,
                    emailAttachements: emailAttachements
                });
                // response = templates//'email sent';
                response = 'email sent';

            } catch (error) {
                response = 'error in sending email';
            }

            // send mail to customer's relationship manger
            if (req.payload.productPlatfom == 'WhatNext') {
                if (req.payload.relationShipManager.user_email != '') {
                    let relationShipManager = req.payload.relationShipManager;
                    templatePath = path.join(templatesDir, 'subscription-relationship-manager')
                    const email = new EmailTemplate({
                        // uncomment below to send emails in development/test env:
                        // send: true
                        transport: transporter,
                        views: {
                            options: {
                                extension: 'handlebars'
                            }
                        }
                    });

                    // console.dir(subscription);
                    // return subscription;
                    const templates = await email.render(templatePath,
                        {
                            user_name: isRecordFound.user_fname + ' ' + isRecordFound.user_lname,
                            user_email: isRecordFound.user_email,
                            product_url: process.env.PRODUCT_WHATNEXT_WEBSITE,
                            subscription: (req.payload.subscriptionHistoryId) ? subscription : [],
                            invoice_pdf: invoicePdf,
                            subscription_status: subscriptionHistory.subscription_status
                        });

                    // console.log(templates);
                    try {
                        let info = transporter.sendMail({
                            from: emailFrom,
                            to: relationShipManager.user_email,
                            subject: 'WhatNext - New Subscription',
                            html: templates
                        });
                        response = templates//'email sent';
                        // response = 'email sent';

                    } catch (error) {
                        response = 'error in sending email';
                    }
                }
            }
        }
        return { response: response };
    },
    sendCustomerPaymentReceipt: async (req) => {
        response = 'To Be Developed..';
        return { response: response };
    },

};