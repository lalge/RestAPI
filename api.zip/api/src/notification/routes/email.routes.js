const EmailController = require('../controllers/email.controller');
const Joi = require('joi');
const _ = require('underscore');
const Functions = require('../../../libs/function');

module.exports = [
    {
        path: '/notification/send-email/login-credentials',
        method: 'POST',
        options: {
            description: 'Send Email with Login credentials',
            notes: "Returns Success",
            tags: ['api'],
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    productPlatfom: Joi.string().valid('WhatNext', 'GenNx', 'IndustryInsider').required(),
                    customerId: Joi.string().min(24).max(24).error(new Error('Please provide valid Customer Id')),
                    userId: Joi.string().min(24).max(24).error(new Error('Please provide valid User Id')),
                    subscriptionHistoryId: Joi.string().min(24).max(24).error(new Error('Please provide valid Subscription History Id')),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    // validate user
                    if (!_.isEmpty(req.payload.customerId)) {
                        // for Customers
                        const sendMailResp = await EmailController.sendCustomerLoginCredentials(req);
                        return h.response(sendMailResp);
                    } else if (!_.isEmpty(req.payload.userId)) {
                        // for GenNx User
                        const sendMailResp = await EmailController.sendUserLoginCredentials(req);
                        return h.response(sendMailResp);
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            // auth:false,
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
        }
    },
    {
        path: '/notification/send-email/subscription',
        method: 'POST',
        options: {
            description: 'Send Email with Subscription details',
            notes: "Returns Success",
            tags: ['api'],
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    productPlatfom: Joi.string().valid('WhatNext', 'GenNx', 'IndustryInsider').required(),
                    customerId: Joi.string().min(24).max(24).error(new Error('Please provide valid Customer Id')),
                    userId: Joi.string().min(24).max(24).error(new Error('Please provide valid User Id')),
                    subscriptionHistoryId: Joi.string().min(24).max(24).error(new Error('Please provide valid Subscription History Id')),
                    relationShipManager: Joi.object({
                        user_fname: Joi.string().allow(''),
                        user_lname: Joi.string().allow(''),
                        user_email: Joi.string().email().allow(''),
                    })
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    // validate user
                    if (!_.isEmpty(req.payload.customerId)) {
                        // for Customers
                        const sendMailResp = await EmailController.sendCustomerSubscriptions(req);
                        return h.response(sendMailResp);
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            // auth:false,
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
        }
    },
    // {
    //     path: '/notification/send-email/payment-receipt',
    //     method: 'POST',
    //     options: {
    //         description: 'Send Email with Payment Receipt',
    //         notes: "Returns Success",
    //         tags: ['api'],
    //         validate: {
    //             options: {
    //                 allowUnknown: true,
    //                 abortEarly: false
    //             },
    //             payload: {
    //                 productPlatfom: Joi.string().valid('WhatNext', 'GenNx', 'IndustryInsider').required(),
    //                 customerId: Joi.string().min(24).max(24).error(new Error('Please provide valid Customer Id')),
    //                 userId: Joi.string().min(24).max(24).error(new Error('Please provide valid User Id')),
    //                 subscription: Joi.array()
    //             },
    //             failAction: async (request, h, err) => {
    //                 return await Functions.failAction(request, h, err);
    //             }
    //         },
    //         handler: async (req, h) => {
    //             try {
    //                 // validate user
    //                 if (!_.isEmpty(req.payload.customerId)) {
    //                     // for Customers
    //                     const sendMailResp = await EmailController.sendCustomerPaymentReceipt(req);
    //                     return h.response(sendMailResp);
    //                 } 
    //             } catch (error) {
    //                 console.log(error);
    //                 // return error;
    //                 return h.response(error);
    //             }

    //         },
    //         // Add authentication to this route
    //         // The user must have a scope of `admin`
    //         // auth:false,
    //         auth: {
    //             strategy: 'jwt',
    //             scope: ['admin']
    //         }
    //     }
    // },
    {
        path: '/notification/send-email/invoice',
        method: 'POST',
        options: {
            description: 'Send Email with Invoice and Payment link details',
            notes: "Returns Success",
            tags: ['api'],
            validate: {
                options: {
                    allowUnknown: true,
                    abortEarly: false
                },
                payload: {
                    productPlatfom: Joi.string().valid('WhatNext', 'GenNx', 'IndustryInsider').required(),
                    customerId: Joi.string().min(24).max(24).error(new Error('Please provide valid Customer Id')),
                    userId: Joi.string().min(24).max(24).error(new Error('Please provide valid User Id')),
                    subscriptionHistoryId: Joi.string().min(24).max(24).error(new Error('Please provide valid Subscription History Id')),
                    relationShipManager: Joi.object({
                        user_fname: Joi.string().allow(''),
                        user_lname: Joi.string().allow(''),
                        user_email: Joi.string().email().allow(''),
                    })
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    // validate user
                    if (!_.isEmpty(req.payload.customerId)) {
                        // for Customers
                        const sendMailResp = await EmailController.sendCustomerInvoice(req);
                        return h.response(sendMailResp);
                    }
                } catch (error) {
                    console.log(error);
                    // return error;
                    return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            // auth:false,
            auth: {
                strategy: 'jwt',
                scope: ['admin']
            }
        }
    },


];