'use strict';
const nodeLinkedin = require('../../../libs/plugins/node-linkedin');
module.exports = [
    {
        path: '/linkedin-signin',
        method: 'GET',
        options: {
            description: 'Sign With LinkedIn',
            notes: 'Redirect to the linkedin page',
            tags: ['service'],
            handler: async (req, h) => {
                try {
                    const Key = process.env.LINKEDIN_SECRET_KEY;
                    const Id = process.env.LINKEDIN_AUTH_ID
                    const RedirectUrl = 'http://' + process.env.PUBLIC_IP + ':' + process.env.PORT + '/' + process.env.LINKEDIN_REDIRECT_ROUTE + '?callback=' + req.query.callback;
                    const Linkedin = nodeLinkedin(Id, Key, RedirectUrl);
                    const auth_url = Linkedin.auth.authorize(['r_liteprofile', 'r_emailaddress']);
                    return h.redirect(auth_url);
                } catch (error) {
                    return error;
                }
            },
            auth: false
        },


    },
    {
        path: '/linkedin-signin-redirect',
        method: 'GET',
        options: {
            description: 'sign in with linkedin',
            notes: 'sign in with linkedin',
            tags: ['service'],
            handler: async (req, h) => {
                try {
                    const Key = process.env.LINKEDIN_SECRET_KEY;
                    const Id = process.env.LINKEDIN_AUTH_ID
                    const RedirectUrl = 'http://' + process.env.PUBLIC_IP + ':' + process.env.PORT + '/' + process.env.LINKEDIN_REDIRECT_ROUTE + '?callback=' + req.query.callback;
                    const Linkedin = nodeLinkedin(Id, Key, RedirectUrl);
                    if (typeof req.query.error !== 'undefined') {
                        return h.redirect(req.query.callback);
                    }
                    const userData = await new Promise(function (resolve, reject) {
                        Linkedin.auth.getAccessToken(req.query.code, req.query.state, async function (err, results) {
                            if (err)
                                reject(err)

                            const linkedin = Linkedin.init(results.access_token, {
                                timeout: 50000 /* 50 seconds */
                            });

                            const userProfile = await new Promise(function (resolveProfile, rejectProfile) {
                                linkedin.people.me(async function (err, profileData) {
                                    if (err)
                                        rejectProfile(profileData);
                                    resolveProfile(profileData);
                                })
                            });

                            var userEmail = await new Promise(function (resolveEmail, rejectEmail) {
                                linkedin.people.email(function (err, userEmailData) {
                                    if(err)
                                        rejectEmail(err);
                                    resolveEmail(userEmailData);
                                })
                            });
                            resolve({
                                userProfile: userProfile,
                                userEmail: userEmail
                            })
                        })
                    });


                    return h.redirect(req.query.callback + '?userData=' + Buffer.from(JSON.stringify(userData)).toString('base64'));

                } catch (error) {
                    return h.redirect(req.query.callback);
                }

            },
            auth: false
        }
    },
];