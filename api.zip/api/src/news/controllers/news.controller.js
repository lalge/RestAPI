//news.controller.js
'use strict';

const LogApiModel = require('../../logs/models/log-api.model');
const Functions = require('../../../libs/function');
const _ = require('underscore');
const fs = require('fs');
const remoteAppDbService = require('../../services/remoteAppDbService');

module.exports = {
    find: async (req) => {
        var search_keyword = '"' + Functions.escapeRegExp(req.query.search_keyword) + '"';

        var pipeline = [];
        var where = { $text: { $search: search_keyword } };
        var limit = (req.query.page !== 'undefined') ? req.query.page : 100;

        if (req.query.industry_name) {
            var keywords = _.map(req.query.industry_name.split('|'), function (num) {
                return '\\b' + Functions.escapeRegExp(num) + '\\b';
            });
            where['news_industry.industry_name'] = new RegExp(keywords.join('|'), 'i');
        }
        if (req.query.trend_name) {
            var keywords = _.map(req.query.trend_name.split('|'), function (num) {
                return '\\b' + Functions.escapeRegExp(num) + '\\b';
            });
            where['news_dt.dt_name'] = new RegExp(keywords.join('|'), 'i');
        }
        if (req.query.news_age) {
            var todayDate = new Date();
            var backDate = new Date();
            backDate = new Date(backDate.setDate(new Date().getDate() - req.query.news_age));
            where['news_published_date'] = { '$gte': backDate, '$lte': todayDate };
        }

        pipeline.push({ $match: where });
        pipeline.push({ $addFields: { score: { $meta: 'textScore' } } });
        pipeline.push({ $sort: { news_published_date: -1, score: -1 } });
        pipeline.push({ $limit: limit });

        // console.log('where');
        // console.log(where);

        // console.log('pipeline');
        // console.log(pipeline);

        var result, reponse = [];

        result = await remoteAppDbService.getDataFromRemoteAppDb({
            remoteAppName: 'whatnext', // whatnext, industryinsider
            storageName: 'inx_news_article',
            dbMethod: 'mongoAggregate', //mongoFind, mongoAggregate
            pipeline: pipeline,
        });
        // console.log("result retured");
        if (!_.isEmpty(result)) {
            // flag to base64 encode 
            let btoaFb = new Buffer('fb').toString('base64');

            var companyIdsArr = []
            var companyData = [];
            _.each(result, function (record) {
                _.each(record['news_company'], function (node) {
                    if (node.company_id != '') {
                        companyIdsArr.push(node.company_id);
                    }
                });
            });
            // console.log('companyIdsArr');
            // console.log(companyIdsArr);
            if (companyIdsArr) {
                companyData =await remoteAppDbService.getDataFromRemoteAppDb({
                    remoteAppName: 'whatnext', // whatnext, industryinsider
                    storageName: 'inx_company',
                    dbMethod: 'mongoFind', //mongoFind, mongoAggregate
                    where: { _id: { $in: companyIdsArr }},
                });
            }
            _.each(result, function (record) {
                var image = record['news_attachment_image'][0];
                var imgBase64data = '';
                if (!_.isEmpty(image['image_file_name'])) {
                    var img_file = process.env.BASE_PATH + '/public/upload/images/news/' + image['image_file_name'];
                    if (fs.existsSync(img_file)) {
                        var buff = fs.readFileSync(img_file);
                        imgBase64data = buff.toString('base64');
                    }

                }

                var entities = [];
                if (!_.isEmpty(record['news_company'])) {
                    _.each(record['news_company'], function (company) {
                        var entity_url = '';
                        if (!_.isEmpty(company['company_id'])) {
                            var companyRecord = _.filter(companyData, function (comp) {
                                return (comp._id.toString() == company['company_id'].toString());
                            });
                            companyRecord = companyRecord[0];

                            companyRecord = companyRecord.toObject();
                            if (!_.isEmpty(companyRecord['company_public_id'])) {
                                entity_url = process.env.SITE_URL + 'profile/company/' + companyRecord['company_public_id'] + '///////' + btoaFb
                            }
                        }
                        entities.push({
                            'entity_id': company['company_id'],
                            'entity_name': company['company_name'],
                            'entity_url': entity_url
                        });
                    });
                }
                var industry_tags = _.map(record['news_industry'], function (node) {
                    return node.industry_name;
                });
                var technology_tags = _.reject(_.map(record['news_dt'], function (node) {
                    return (node['dt_parent_id'] == 0) ? node['dt_name'] : null;
                }), _.isNull);

                // id to base64 encode 
                let btoaId = new Buffer(record['_id'].toString()).toString('base64');

                reponse.push({
                    'news_id': record['_id'],
                    'news_title': record['news_title'],
                    'news_description': record['news_content'],
                    'news_source': record['news_source'],
                    'news_source_url': record['news_source_url'],
                    'news_published_date': record['news_published_date'],
                    'news_image': imgBase64data,
                    'entities': entities,
                    'industry_tags': industry_tags,
                    'technology_tags': technology_tags,
                    'news_public_url': process.env.SITE_URL + 'news-story/' + btoaId + '//////' + btoaFb,
                    'score': record['score']
                });
            });
            console.log('reponse returned');
            // console.log(reponse);
        }

        // insert API log
        const apiLog = new LogApiModel({
            request_date: new Date(),
            request_params: req.query,
            request_api: req.path,
            response_count: reponse.length,
        });
        await apiLog.save();
        return reponse;
    }


};