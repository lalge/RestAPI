//import the Mongoose package

const Db = require('../../../database');
const Mongoose = require('mongoose');
// console.dir(Mongoose);
//get the Schema class
const Schema = Mongoose.Schema;

// const NewsSchema = new Schema({
//     news_id: {
//         type: String
//     },
//     _id: {
//         required: true,
//         type: String
//     },
//     news_title:{
//         required: true,
//         type: String
//     },
//     news_content:{
//         type: String
//     },
// });
module.exports = Mongoose.model('inx_news_article', Mongoose.Schema(),'inx_news_article');