module.exports = [{
    path: '/',
    method: 'GET',
    options: {
        description: 'Home',
        notes: 'This is home',
        tags: [],
        handler: async (req, h) => {
            return 'Welcome to WhatNext API!!';
        }
        , auth: false
    }

},
{
    path: '/testApi',
    method: 'GET',
    options: {
        description: 'Sample Test API',
        notes: 'This is home',
        tags: [],
        handler: async (req, h) => {
            // let sha1 = require('sha1');
            // var pass = sha1(sha1('IndustryInsider') + '::' + process.env.SALT)
            // return h.response(pass);
            const Functions = require('../../../libs/function');

            return h.response({ date: Functions.covertDateToLocalTime(new Date('2019-12-12T09:23:50.000+0000'),'DD MMM Y') });
            // let remoteAppDbService = require('../../services/remoteAppDbService');

            // const result = await remoteAppDbService.setDataInRemoteAppDb({
            //     remoteAppName: 'whatnext', // whatnext, industryinsider
            //     storageName: 'inx_user',
            //     dbMethod: 'mongoUpdate', // mongoUpdate, mongoInsert
            //     where: { user_email: req.query.user_email },
            //     data: { $set:{ user_company: 'Cheers New' }}
            // });


            // const result = await remoteAppDbService.getDataFromRemoteAppDb({
            //     remoteAppName: 'whatnext', // whatnext, industryinsider
            //     storageName: 'inx_user',
            //     dbMethod: 'mongoFind', // mongoUpdate, mongoInsert
            //     where: { user_email: 'suraj.varane@cheersin.com' },
            // });

            // var file = Functions.convertBase64ImageToFile({
            //     base64String: req.payload.user_profile_picture,
            // });
            return h.response(result);
        },
        auth: false
    }

}].concat(
    // news,company,
    require('../../auth/routes/auth.routes'),
    require('../../customer/routes/customer.routes'),
    require('../../sitesearch/routes/sitesearch.routes'),
    require('../../subscription/routes/subscription.routes'),
    require('../../subscription/routes/promocode.routes'),
    require('../../users/routes/users.routes'),
    require('../../taxonomy/routes/taxonomy.routes'),
    require('../../bdsystem/routes/bdsystem.routes'),
    require('../../notification/routes/email.routes'),
    require('../../thirdpartysignup/routes/linkedin-singup.route')
);