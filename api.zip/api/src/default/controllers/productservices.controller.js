//productservices.controller.js
const ProductServices = require('../models/productservices.model');
const Mongoose = require('mongoose');
const _ = require('underscore');

module.exports = {
    find: async (req) => {
        
        var where = {};
        if(typeof req.query.product_id !="undefined"){
            where = (!_.isEmpty(req.query.product_id)) ? {'_id' : Mongoose.Types.ObjectId(req.query.product_id)} : {};
        }
        var result = [];
        result = await ProductServices.find(where);
        //console.log('====RESULT====',result);
        return result;
    },

};