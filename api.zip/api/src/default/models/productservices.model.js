//import the Mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;

const ProductServicesSchema = new Schema({
    _id: {
        required: true,
        type: String
    },
    product_service_name:{
        type: String
    },
    product_api_token:{
        type: String
    }
});
module.exports = Mongoose.model('api_services', ProductServicesSchema,'api_services');