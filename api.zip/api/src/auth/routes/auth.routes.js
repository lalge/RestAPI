//User.routes.js
'use strict';
const AuthController = require('../controllers/auth.controller');
var Joi = require('joi');
const Boom = require('boom');
const Functions = require('../../../libs/function');
module.exports = [
    { 
        path: '/authenticate',
        method: 'POST',
        options: {
            description: 'API Login Authenticate',
            notes: 'Returns jwt token on succsfully Authenticate',
            tags: ['api'],
            // Validate the payload against the Joi schema
            validate: {
                payload: {
                    api_auth_username: Joi.string().required(),
                    api_auth_password: Joi.string().required(),
                    auth_application_key: Joi.string().required(),
                },
                failAction: async (request, h, err) => {
                    return await Functions.failAction(request, h, err);
                }
            },
            handler: async (req, h) => {
                try {
                    // validate user

                    // const isValidUser = await 

                    const isValidUser = await AuthController.verifyCredentials(req, h);
                    if (isValidUser.success) {
                        //  generate jwt token
                        return { token: await Functions.createToken(isValidUser.success) };
                    } else {
                        return isValidUser.error;
                    }
                } catch (error) {
                    console.log(error);
                    return error;
                    // return h.response(error);
                }

            },
            // Add authentication to this route
            // The user must have a scope of `admin`
            auth: false

        }

    }
];