//news.controller.js
'use strict';
const ApiUserModel = require('../models/apiuser.model');
const ProductServiceModel = require('../../default/models/productservices.model');
const sha1 = require('sha1');
const Boom = require('boom');

module.exports = {
    verifyCredentials: async (req) => {
        let password = sha1(sha1(req.payload.api_auth_password) + '::' + process.env.SALT)
        var user = await ApiUserModel.findOne({
            api_auth_password: password,
            api_auth_username: req.payload.api_auth_username,
        });
        if (user) {
            // Verify Application 
            var validApplication = await ProductServiceModel.findOne({
                product_api_token: req.payload.auth_application_key,
            });
            if (validApplication) {
                return { success: user,error:'' };
            } else {
                return { error: Boom.badRequest('Incorrect Application Key!') };
            }
        } else {
            return { error: Boom.badRequest('Incorrect username or email!') };
            // h(Boom.badRequest('Incorrect username or email!'));
        }
    },



};