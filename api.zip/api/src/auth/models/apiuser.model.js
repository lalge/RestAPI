//import the Mongoose package
const Mongoose = require('mongoose');
//get the Schema class
const Schema = Mongoose.Schema;
ObjectId = Schema.ObjectId;
const ApiAuthSchema = new Schema({
    _id: {
        required: true,
        type: ObjectId
    },
    api_auth_password:{
        required: true,
        type: String
    },
    api_auth_username:{
        required: true,
        type: String
    },
    api_auth_scope:{
        type: Array
    },
}, { strict: false,versionKey: false });
module.exports = Mongoose.model('api_auth_users', ApiAuthSchema,'api_auth_users');